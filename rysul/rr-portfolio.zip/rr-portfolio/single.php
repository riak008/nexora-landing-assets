<?php
/** Project page: renders the "portfolio-project-template" page (Elementor) whose [rr_project] shortcode shows this project. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$rr_tpl = RR_Portfolio::template_id();
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'rr-project-page' ); ?>>
<?php
wp_body_open();
if ( $rr_tpl && class_exists( '\Elementor\Plugin' ) ) {
	echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $rr_tpl, true ); // phpcs:ignore WordPress.Security.EscapeOutput
} else {
	echo '<main class="rr-wrap" style="padding:40px 20px">' . do_shortcode( '[rr_project]' ) . '</main>'; // phpcs:ignore WordPress.Security.EscapeOutput
}
wp_footer();
?>
</body>
</html>
