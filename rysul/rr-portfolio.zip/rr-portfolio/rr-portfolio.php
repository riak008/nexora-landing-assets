<?php
/**
 * Plugin Name: RR Portfolio
 * Description: Portfolio / case studies for this site. Add, edit or remove projects in Portfolio; cards and project pages update automatically. Works with any theme and needs no other plugin.
 * Version: 1.0.0
 * Author: Rysul Islam Riak
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: rr-portfolio
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RR_Portfolio {
	const PT   = 'rr_project';
	const TAX  = 'rr_project_type';
	const META = array(
		'rr_tag'      => 'Card label (e.g. Local SEO)',
		'rr_industry' => 'Industry',
		'rr_service'  => 'Service name',
		'rr_service_url' => 'Service page URL',
		'rr_order_url'   => 'Order button URL',
		'rr_order_label' => 'Order button text',
		'rr_metrics'  => 'Key numbers, one per line: value | label',
	);

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'box' ) );
		add_action( 'save_post_' . self::PT, array( __CLASS__, 'save' ) );
		add_shortcode( 'rr_portfolio', array( __CLASS__, 'grid' ) );
		add_shortcode( 'rr_project', array( __CLASS__, 'single' ) );
		add_filter( 'template_include', array( __CLASS__, 'template' ), 99 );
		add_filter( 'manage_' . self::PT . '_posts_columns', array( __CLASS__, 'cols' ) );
		add_action( 'manage_' . self::PT . '_posts_custom_column', array( __CLASS__, 'col' ), 10, 2 );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
	}

	public static function register() {
		register_post_type( self::PT, array(
			'labels'        => array( 'name' => 'Portfolio', 'singular_name' => 'Project', 'add_new' => 'Add New Project', 'add_new_item' => 'Add New Project', 'edit_item' => 'Edit Project', 'all_items' => 'All Projects', 'featured_image' => 'Card image', 'set_featured_image' => 'Set card image' ),
			'public'        => true,
			'show_in_rest'  => true,
			'menu_icon'     => 'dashicons-portfolio',
			'menu_position' => 21,
			'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes', 'custom-fields' ),
			'has_archive'   => false,
			'rewrite'       => array( 'slug' => 'portfolio', 'with_front' => false ),
		) );
		register_taxonomy( self::TAX, self::PT, array( 'label' => 'Project types', 'public' => true, 'hierarchical' => true, 'show_in_rest' => true, 'show_admin_column' => true, 'rewrite' => array( 'slug' => 'portfolio-type' ) ) );
		foreach ( array_keys( self::META ) as $k ) {
			register_post_meta( self::PT, $k, array( 'type' => 'string', 'single' => true, 'show_in_rest' => true, 'auth_callback' => function () { return current_user_can( 'edit_posts' ); } ) );
		}
		register_post_meta( self::PT, 'rr_gallery', array( 'type' => 'string', 'single' => true, 'show_in_rest' => true, 'auth_callback' => function () { return current_user_can( 'edit_posts' ); } ) );
		if ( get_option( 'rr_portfolio_flush' ) !== '1' ) {
			flush_rewrite_rules( false );
			update_option( 'rr_portfolio_flush', '1' );
		}
	}

	public static function box() {
		add_meta_box( 'rr_project_details', 'Project details (card & page)', array( __CLASS__, 'box_html' ), self::PT, 'normal', 'high' );
	}

	public static function box_html( $post ) {
		wp_nonce_field( 'rr_project_save', 'rr_project_nonce' );
		echo '<p style="color:#555">Title = card headline · Excerpt = short card text · Card image = featured image · Content = full project details.</p><table class="form-table">';
		foreach ( self::META as $k => $label ) {
			$v = get_post_meta( $post->ID, $k, true );
			echo '<tr><th><label for="' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td>';
			if ( 'rr_metrics' === $k ) {
				echo '<textarea id="' . esc_attr( $k ) . '" name="' . esc_attr( $k ) . '" rows="4" class="large-text" placeholder="931K | Clicks in 16 months">' . esc_textarea( $v ) . '</textarea>';
			} else {
				echo '<input type="text" id="' . esc_attr( $k ) . '" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '" class="regular-text">';
			}
			echo '</td></tr>';
		}
		echo '</table>';
	}

	public static function save( $id ) {
		if ( ! isset( $_POST['rr_project_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['rr_project_nonce'] ) ), 'rr_project_save' ) || ! current_user_can( 'edit_post', $id ) ) {
			return;
		}
		foreach ( array_keys( self::META ) as $k ) {
			if ( isset( $_POST[ $k ] ) ) {
				$raw = wp_unslash( $_POST[ $k ] );
				update_post_meta( $id, $k, 'rr_metrics' === $k ? sanitize_textarea_field( $raw ) : ( false !== strpos( $k, '_url' ) ? esc_url_raw( $raw ) : sanitize_text_field( $raw ) ) );
			}
		}
	}

	public static function cols( $c ) {
		return array_slice( $c, 0, 1, true ) + array( 'rr_img' => 'Image' ) + array_slice( $c, 1, null, true );
	}

	public static function col( $c, $id ) {
		if ( 'rr_img' === $c ) {
			echo get_the_post_thumbnail( $id, array( 80, 50 ) );
		}
	}

	public static function notice() {
		$s = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $s && 'edit-' . self::PT === $s->id ) {
			echo '<div class="notice notice-info"><p>Projects here appear automatically on the Portfolio page, the home page and related pages. Drag order: set <b>Order</b> under Page Attributes (lower shows first). Trash a project to remove it from the site.</p></div>';
		}
	}

	private static function metrics( $id ) {
		$out = array();
		foreach ( preg_split( '/\r?\n/', (string) get_post_meta( $id, 'rr_metrics', true ) ) as $line ) {
			$p = array_map( 'trim', explode( '|', $line, 2 ) );
			if ( '' !== $p[0] ) {
				$out[] = array( $p[0], isset( $p[1] ) ? $p[1] : '' );
			}
		}
		return $out;
	}

	public static function card( $id ) {
		$img = get_the_post_thumbnail( $id, 'large', array( 'loading' => 'lazy', 'alt' => esc_attr( get_the_title( $id ) . ' – results' ) ) );
		$tag = get_post_meta( $id, 'rr_tag', true );
		return '<a class="rr-case" href="' . esc_url( get_permalink( $id ) ) . '">' . $img . '<div>' . ( $tag ? '<span class="rr-tag">' . esc_html( $tag ) . '</span>' : '' )
			. '<h3>' . esc_html( get_the_title( $id ) ) . '</h3><p>' . esc_html( get_the_excerpt( $id ) ) . '</p><span class="rr-more">Read case study →</span></div></a>';
	}

	public static function grid( $atts ) {
		$a = shortcode_atts( array( 'limit' => -1, 'type' => '', 'service' => '', 'exclude' => '' ), $atts );
		$q = array( 'post_type' => self::PT, 'posts_per_page' => (int) $a['limit'], 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'DESC' ), 'no_found_rows' => true );
		if ( $a['type'] ) {
			$q['tax_query'] = array( array( 'taxonomy' => self::TAX, 'field' => 'slug', 'terms' => array_map( 'trim', explode( ',', $a['type'] ) ) ) );
		}
		if ( $a['service'] ) {
			$q['meta_query'] = array( array( 'key' => 'rr_service', 'value' => $a['service'] ) );
		}
		if ( $a['exclude'] ) {
			$q['post__not_in'] = array_map( 'intval', explode( ',', $a['exclude'] ) );
		}
		$ids = get_posts( $q + array( 'fields' => 'ids' ) );
		if ( ! $ids && $a['service'] ) {
			unset( $q['meta_query'] );
			$ids = get_posts( $q + array( 'fields' => 'ids' ) );
		}
		return $ids ? '<div class="rr-cases">' . implode( '', array_map( array( __CLASS__, 'card' ), $ids ) ) . '</div>' : '';
	}

	/** The project page body. Used inside the "Portfolio project template" page so its header, footer and styles come from the site design. */
	public static function single() {
		$post = get_queried_object();
		if ( ! $post instanceof WP_Post || self::PT !== $post->post_type ) {
			$p = get_posts( array( 'post_type' => self::PT, 'numberposts' => 1 ) );
			$post = $p ? $p[0] : null;
		}
		if ( ! $post ) {
			return '';
		}
		$id    = $post->ID;
		$tag   = get_post_meta( $id, 'rr_tag', true );
		$title = esc_html( get_the_title( $id ) );
		if ( false !== strpos( $title, ': ' ) ) {
			$title = preg_replace( '/: /', ': <span>', $title, 1 ) . '</span>';
		}
		$order = get_post_meta( $id, 'rr_order_url', true ) ?: home_url( '/hire-me/' );
		$label = get_post_meta( $id, 'rr_order_label', true ) ?: 'Get results like this';
		$h  = '<section class="rr-dark rr-sec rr-phero"><div class="rr-wrap" style="text-align:center"><p class="rr-pill-d">Case study' . ( $tag ? ' · ' . esc_html( $tag ) : '' ) . '</p><h1 class="rr-ph1">' . $title . '</h1>';
		$h .= '<p class="rr-plead">' . esc_html( get_the_excerpt( $id ) ) . '</p><div class="rr-pbtns"><a class="g" href="' . esc_url( $order ) . '">' . esc_html( $label ) . ' →</a><a class="w" href="' . esc_url( home_url( '/portfolio/' ) ) . '">All case studies</a></div></div></section>';
		$m = self::metrics( $id );
		if ( $m ) {
			$h .= '<section class="rr-sec-sm rr-soft"><div class="rr-wrap"><div class="rr-stats">';
			foreach ( $m as $x ) {
				$h .= '<div><b>' . esc_html( $x[0] ) . '</b><span>' . esc_html( $x[1] ) . '</span></div>';
			}
			$h .= '</div></div></section>';
		}
		$content = apply_filters( 'the_content', $post->post_content );
		$facts   = '<div class="rr-facts"><h3>Project facts</h3><ul>';
		foreach ( array( 'rr_industry' => 'Industry', 'rr_service' => 'Service' ) as $k => $l ) {
			$v = get_post_meta( $id, $k, true );
			if ( $v ) {
				$u = 'rr_service' === $k ? get_post_meta( $id, 'rr_service_url', true ) : '';
				$facts .= '<li><span>' . $l . '</span>' . ( $u ? '<a href="' . esc_url( $u ) . '">' . esc_html( $v ) . '</a>' : esc_html( $v ) ) . '</li>';
			}
		}
		$facts .= '<li><span>Role</span>SEO Specialist</li><li><span>Data</span>Google Search Console</li><li><span>Client</span>Hidden for privacy</li></ul>';
		$facts .= '<a class="b1" href="' . esc_url( $order ) . '">' . esc_html( $label ) . '</a><a class="b2" href="' . esc_url( home_url( '/seo-audit/' ) ) . '">Get a free SEO audit</a><a class="b2" href="' . esc_url( home_url( '/seo-consultation/' ) ) . '">Book a call</a></div>';
		$h .= '<section class="rr-sec"><div class="rr-wrap rr-pgrid"><article class="rr-pbody">' . $content . '</article><aside class="rr-side">' . $facts . '</aside></div></section>';
		$more = self::grid( array( 'limit' => 3, 'exclude' => $id, 'service' => get_post_meta( $id, 'rr_service', true ) ) );
		if ( $more ) {
			$h .= '<section class="rr-sec rr-soft"><div class="rr-wrap"><h2 class="rr-ph2">More case studies</h2>' . $more . '</div></section>';
		}
		return $h;
	}

	/** Project pages use the page named "portfolio-project-template" (built in Elementor) for header, footer and styles. */
	public static function template( $t ) {
		if ( is_singular( self::PT ) ) {
			$f = __DIR__ . '/single.php';
			if ( file_exists( $f ) ) {
				return $f;
			}
		}
		return $t;
	}

	public static function template_id() {
		$p = get_page_by_path( 'portfolio-project-template' );
		return $p ? (int) $p->ID : 0;
	}
}
RR_Portfolio::init();
register_activation_hook( __FILE__, function () {
	delete_option( 'rr_portfolio_flush' );
} );
