<?php
/**
 * Plugin Name: RR Site Manager
 * Description: One clean place to run the site: gigs, portfolio, payments, tracking and lead tools. Works with RR Gigs, RR Portfolio and RR Growth Kit.
 * Version: 1.0.0
 * Author: Rysul Islam Riak
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RR_Site_Manager {
	const SLUG = 'rr-site';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 5 );
		add_action( 'admin_menu', array( __CLASS__, 'tidy_menu' ), 999 );
		add_action( 'admin_post_rrm_save_gig', array( __CLASS__, 'save_gig' ) );
		add_action( 'admin_post_rrm_save_project', array( __CLASS__, 'save_project' ) );
		add_action( 'admin_post_rrm_action', array( __CLASS__, 'row_action' ) );
		add_action( 'admin_post_rrm_save_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_init', array( __CLASS__, 'redirect_core_screens' ) );
		add_filter( 'get_edit_post_link', array( __CLASS__, 'edit_link' ), 10, 2 );
	}

	/* ---------------- menu & routing ---------------- */

	public static function menu() {
		add_menu_page( 'Rysul Site', 'Rysul Site', 'edit_posts', self::SLUG, array( __CLASS__, 'router' ), 'dashicons-star-filled', 2 );
		add_submenu_page( self::SLUG, 'Overview', 'Overview', 'edit_posts', self::SLUG, array( __CLASS__, 'router' ) );
		add_submenu_page( self::SLUG, 'Gigs', 'Gigs', 'edit_posts', self::SLUG . '-gigs', array( __CLASS__, 'router' ) );
		add_submenu_page( self::SLUG, 'Portfolio', 'Portfolio', 'edit_posts', self::SLUG . '-portfolio', array( __CLASS__, 'router' ) );
		add_submenu_page( self::SLUG, 'Settings & tracking', 'Settings & tracking', 'manage_options', self::SLUG . '-settings', array( __CLASS__, 'router' ) );
	}

	/** The old CPT menus stay reachable from inside the manager but leave the sidebar. */
	public static function tidy_menu() {
		remove_menu_page( 'edit.php?post_type=rr_gig' );
		remove_menu_page( 'edit.php?post_type=rr_project' );
		remove_submenu_page( 'options-general.php', 'rr-growth-kit' );
	}

	public static function url( $page = '', $args = array() ) {
		return add_query_arg( $args, admin_url( 'admin.php?page=' . self::SLUG . ( $page ? '-' . $page : '' ) ) );
	}

	public static function edit_link( $link, $id ) {
		$t = get_post_type( $id );
		if ( 'rr_gig' === $t && empty( $_GET['classic'] ) ) { // phpcs:ignore
			return self::url( 'gigs', array( 'edit' => $id ) );
		}
		if ( 'rr_project' === $t && empty( $_GET['classic'] ) ) { // phpcs:ignore
			return self::url( 'portfolio', array( 'edit' => $id ) );
		}
		return $link;
	}

	public static function redirect_core_screens() {
		global $pagenow;
		$pt = isset( $_GET['post_type'] ) ? sanitize_key( $_GET['post_type'] ) : ''; // phpcs:ignore
		if ( 'post-new.php' === $pagenow && in_array( $pt, array( 'rr_gig', 'rr_project' ), true ) ) {
			wp_safe_redirect( self::url( 'rr_gig' === $pt ? 'gigs' : 'portfolio', array( 'edit' => 'new' ) ) );
			exit;
		}
		if ( 'edit.php' === $pagenow && in_array( $pt, array( 'rr_gig', 'rr_project' ), true ) && empty( $_GET['page'] ) ) { // phpcs:ignore
			wp_safe_redirect( self::url( 'rr_gig' === $pt ? 'gigs' : 'portfolio' ) );
			exit;
		}
		if ( 'post.php' === $pagenow && isset( $_GET['post'], $_GET['action'] ) && 'edit' === $_GET['action'] && empty( $_GET['classic'] ) ) { // phpcs:ignore
			$id = (int) $_GET['post']; // phpcs:ignore
			$t  = get_post_type( $id );
			if ( in_array( $t, array( 'rr_gig', 'rr_project' ), true ) ) {
				wp_safe_redirect( self::url( 'rr_gig' === $t ? 'gigs' : 'portfolio', array( 'edit' => $id ) ) );
				exit;
			}
		}
		if ( 'options-general.php' === $pagenow && isset( $_GET['page'] ) && 'rr-growth-kit' === $_GET['page'] ) { // phpcs:ignore
			wp_safe_redirect( self::url( 'settings' ) );
			exit;
		}
	}

	public static function router() {
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : self::SLUG; // phpcs:ignore
		$edit = isset( $_GET['edit'] ) ? sanitize_key( $_GET['edit'] ) : ''; // phpcs:ignore
		echo '<div class="rrm">';
		self::topbar( $page );
		self::notice();
		switch ( $page ) {
			case self::SLUG . '-gigs':
				'' !== $edit ? self::gig_form( $edit ) : self::gig_list();
				break;
			case self::SLUG . '-portfolio':
				'' !== $edit ? self::project_form( $edit ) : self::project_list();
				break;
			case self::SLUG . '-settings':
				self::settings();
				break;
			default:
				self::overview();
		}
		echo '</div>';
	}

	private static function topbar( $page ) {
		$tabs = array(
			self::SLUG               => array( 'Overview', '' ),
			self::SLUG . '-gigs'      => array( 'Gigs', 'gigs' ),
			self::SLUG . '-portfolio' => array( 'Portfolio', 'portfolio' ),
			self::SLUG . '-settings'  => array( 'Settings & tracking', 'settings' ),
		);
		echo '<header class="rrm-top"><div class="rrm-brand"><span>R</span><div><b>Rysul Site</b><small>Manage everything in one place</small></div></div><nav>';
		foreach ( $tabs as $k => $t ) {
			echo '<a class="' . ( $k === $page ? 'on' : '' ) . '" href="' . esc_url( self::url( $t[1] ) ) . '">' . esc_html( $t[0] ) . '</a>';
		}
		echo '</nav><a class="rrm-btn ghost" href="' . esc_url( home_url( '/' ) ) . '" target="_blank">View site ↗</a></header>';
	}

	private static function notice() {
		$m = isset( $_GET['rrm_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['rrm_msg'] ) ) : ''; // phpcs:ignore
		if ( $m ) {
			echo '<div class="rrm-toast">✓ ' . esc_html( $m ) . '</div>';
		}
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_editor();
		wp_register_style( 'rrm', false, array(), '1.0.0' );
		wp_enqueue_style( 'rrm' );
		wp_add_inline_style( 'rrm', self::css() );
		wp_register_script( 'rrm', false, array( 'jquery', 'media-editor' ), '1.0.0', true );
		wp_enqueue_script( 'rrm' );
		wp_add_inline_script( 'rrm', self::js() );
	}

	/* ---------------- overview ---------------- */

	private static function overview() {
		$gigs  = wp_count_posts( 'rr_gig' );
		$proj  = wp_count_posts( 'rr_project' );
		$gk    = get_option( 'rr_growth_kit', array() );
		$track = array(
			'Google Analytics 4'   => ! empty( $gk['ga4'] ),
			'Google Tag Manager'   => ! empty( $gk['gtm'] ),
			'Microsoft Clarity'    => ! empty( $gk['clarity'] ),
			'Search Console'       => ! empty( $gk['gsc'] ),
			'Meta Pixel'           => ! empty( $gk['meta_pixel'] ),
			'LinkedIn Insight'     => ! empty( $gk['linkedin'] ),
		);
		echo '<section class="rrm-hero"><div><h1>Welcome back, Rysul 👋</h1><p>Add a gig or a case study, change prices, or check tracking. Everything saves straight to the live site.</p></div><div class="rrm-actions">'
			. '<a class="rrm-btn" href="' . esc_url( self::url( 'gigs', array( 'edit' => 'new' ) ) ) . '">+ New gig</a>'
			. '<a class="rrm-btn light" href="' . esc_url( self::url( 'portfolio', array( 'edit' => 'new' ) ) ) . '">+ New case study</a></div></section>';
		echo '<div class="rrm-stats">';
		self::stat( (int) $gigs->publish, 'Live gigs', self::url( 'gigs' ), (int) $gigs->draft ? (int) $gigs->draft . ' drafts' : 'All published' );
		self::stat( (int) $proj->publish, 'Case studies', self::url( 'portfolio' ), (int) $proj->draft ? (int) $proj->draft . ' drafts' : 'All published' );
		$on = count( array_filter( $track ) );
		self::stat( $on . '/' . count( $track ), 'Tracking tools on', self::url( 'settings' ), $on ? 'Events are being sent' : 'Add your IDs' );
		$lim = class_exists( 'RR_Gigs' ) ? RR_Gigs::opt( 'limit', '20000' ) : '20000';
		self::stat( '৳' . number_format( (float) $lim ), 'Mobile banking limit', self::url( 'settings' ), 'Above it: bank / Payoneer' );
		echo '</div><div class="rrm-cols"><div class="rrm-card"><h2>Tracking status</h2><ul class="rrm-checks">';
		foreach ( $track as $n => $ok ) {
			echo '<li class="' . ( $ok ? 'ok' : '' ) . '"><i>' . ( $ok ? '✓' : '○' ) . '</i>' . esc_html( $n ) . '<span>' . ( $ok ? 'Connected' : 'Not set' ) . '</span></li>';
		}
		echo '</ul><a class="rrm-link" href="' . esc_url( self::url( 'settings' ) . '#tracking' ) . '">Manage tracking →</a></div>';
		echo '<div class="rrm-card"><h2>Quick links</h2><div class="rrm-quick">';
		$q = array(
			'Gigs page'        => home_url( '/hire-me/' ),
			'Portfolio page'   => home_url( '/portfolio/' ),
			'Payments'         => admin_url( 'admin.php?page=nexora-pay' ),
			'Bookings'         => home_url( '/book/' ),
			'Edit pages'       => admin_url( 'edit.php?post_type=page' ),
			'SEO (Rank Math)'  => admin_url( 'admin.php?page=rank-math' ),
			'Media library'    => admin_url( 'upload.php' ),
			'Gig categories'   => admin_url( 'edit-tags.php?taxonomy=rr_gig_cat&post_type=rr_gig' ),
		);
		foreach ( $q as $n => $u ) {
			echo '<a href="' . esc_url( $u ) . '"' . ( 0 === strpos( $u, home_url() ) && false === strpos( $u, 'wp-admin' ) ? ' target="_blank"' : '' ) . '>' . esc_html( $n ) . '</a>';
		}
		echo '</div></div></div>';
	}

	private static function stat( $v, $l, $u, $s ) {
		echo '<a class="rrm-stat" href="' . esc_url( $u ) . '"><b>' . esc_html( $v ) . '</b><span>' . esc_html( $l ) . '</span><small>' . esc_html( $s ) . '</small></a>';
	}

	/* ---------------- lists ---------------- */

	private static function items( $pt ) {
		return get_posts( array( 'post_type' => $pt, 'post_status' => array( 'publish', 'draft', 'pending', 'private' ), 'posts_per_page' => -1, 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'DESC' ) ) );
	}

	private static function act( $id, $do, $label, $cls = '' ) {
		$u = wp_nonce_url( admin_url( 'admin-post.php?action=rrm_action&do=' . $do . '&id=' . $id ), 'rrm_act_' . $id );
		return '<a class="' . esc_attr( $cls ) . '" href="' . esc_url( $u ) . '"' . ( 'trash' === $do ? ' onclick="return confirm(\'Move this to the trash? You can restore it from Trash.\')"' : '' ) . '>' . esc_html( $label ) . '</a>';
	}

	private static function list_head( $title, $sub, $new_url, $new_label, $search_ph ) {
		echo '<div class="rrm-head"><div><h1>' . esc_html( $title ) . '</h1><p>' . esc_html( $sub ) . '</p></div><div class="rrm-actions"><input type="search" class="rrm-search" placeholder="' . esc_attr( $search_ph ) . '"><a class="rrm-btn" href="' . esc_url( $new_url ) . '">' . esc_html( $new_label ) . '</a></div></div>';
	}

	private static function gig_list() {
		self::list_head( 'Gigs', 'Your Fiverr-style gigs. Drag ⠿ to change the order on the site, click a gig to edit it.', self::url( 'gigs', array( 'edit' => 'new' ) ), '+ New gig', 'Search gigs…' );
		$cats = get_terms( array( 'taxonomy' => 'rr_gig_cat', 'hide_empty' => false ) );
		echo '<div class="rrm-chips"><button class="on" data-f="">All</button>';
		foreach ( is_array( $cats ) ? $cats : array() as $c ) {
			echo '<button data-f="' . esc_attr( $c->slug ) . '">' . esc_html( $c->name ) . '</button>';
		}
		echo '<button data-f="draft">Drafts</button></div><div class="rrm-grid" data-sort="rr_gig">';
		foreach ( self::items( 'rr_gig' ) as $p ) {
			$pk    = class_exists( 'RR_Gigs' ) ? RR_Gigs::packages( $p->ID ) : array();
			$from  = $pk ? min( wp_list_pluck( $pk, 'price' ) ) : 0;
			$terms = wp_get_post_terms( $p->ID, 'rr_gig_cat', array( 'fields' => 'all' ) );
			$slugs = implode( ' ', wp_list_pluck( (array) $terms, 'slug' ) ) . ( 'publish' !== $p->post_status ? ' draft' : '' );
			$plat  = get_post_meta( $p->ID, 'rr_platform', true );
			$edit  = self::url( 'gigs', array( 'edit' => $p->ID ) );
			echo '<article class="rrm-item" data-id="' . (int) $p->ID . '" data-f="' . esc_attr( $slugs ) . '" data-s="' . esc_attr( strtolower( $p->post_title ) ) . '">'
				. '<span class="rrm-drag" title="Drag to reorder">⠿</span>'
				. '<a class="rrm-thumb" href="' . esc_url( $edit ) . '">' . ( has_post_thumbnail( $p ) ? get_the_post_thumbnail( $p, 'medium' ) : '<em>No cover</em>' ) . ( 'publish' !== $p->post_status ? '<i class="rrm-badge draft">Draft</i>' : '' ) . ( $plat ? '<i class="rrm-badge ' . esc_attr( strtolower( $plat ) ) . '">' . esc_html( $plat ) . '</i>' : '' ) . '</a>'
				. '<div class="rrm-body"><small>' . esc_html( $terms ? $terms[0]->name : 'No category' ) . '</small><a class="rrm-title" href="' . esc_url( $edit ) . '">' . esc_html( $p->post_title ?: '(no title)' ) . '</a>'
				. '<div class="rrm-meta"><span>From <b>$' . esc_html( (string) $from ) . '</b></span><span>' . count( $pk ) . ' package' . ( 1 === count( $pk ) ? '' : 's' ) . '</span></div>'
				. '<div class="rrm-row-actions"><a href="' . esc_url( $edit ) . '">Edit</a><a href="' . esc_url( get_permalink( $p ) ) . '" target="_blank">View</a>'
				. self::act( $p->ID, 'publish' === $p->post_status ? 'draft' : 'publish', 'publish' === $p->post_status ? 'Unpublish' : 'Publish' )
				. self::act( $p->ID, 'copy', 'Duplicate' ) . self::act( $p->ID, 'trash', 'Delete', 'danger' ) . '</div></div></article>';
		}
		echo '</div>';
	}

	private static function project_list() {
		self::list_head( 'Portfolio', 'Case studies shown on the Portfolio page and on service pages. Drag ⠿ to reorder.', self::url( 'portfolio', array( 'edit' => 'new' ) ), '+ New case study', 'Search case studies…' );
		echo '<div class="rrm-grid" data-sort="rr_project">';
		foreach ( self::items( 'rr_project' ) as $p ) {
			$edit = self::url( 'portfolio', array( 'edit' => $p->ID ) );
			$m    = array_filter( array_map( 'trim', preg_split( '/\r?\n/', (string) get_post_meta( $p->ID, 'rr_metrics', true ) ) ) );
			$top  = $m ? explode( '|', reset( $m ) ) : array();
			echo '<article class="rrm-item" data-id="' . (int) $p->ID . '" data-f="' . ( 'publish' !== $p->post_status ? 'draft' : '' ) . '" data-s="' . esc_attr( strtolower( $p->post_title ) ) . '">'
				. '<span class="rrm-drag" title="Drag to reorder">⠿</span>'
				. '<a class="rrm-thumb" href="' . esc_url( $edit ) . '">' . ( has_post_thumbnail( $p ) ? get_the_post_thumbnail( $p, 'medium' ) : '<em>No image</em>' ) . ( 'publish' !== $p->post_status ? '<i class="rrm-badge draft">Draft</i>' : '' ) . '</a>'
				. '<div class="rrm-body"><small>' . esc_html( get_post_meta( $p->ID, 'rr_tag', true ) ?: 'Case study' ) . '</small><a class="rrm-title" href="' . esc_url( $edit ) . '">' . esc_html( $p->post_title ?: '(no title)' ) . '</a>'
				. '<div class="rrm-meta">' . ( $top ? '<span><b>' . esc_html( trim( $top[0] ) ) . '</b> ' . esc_html( trim( $top[1] ?? '' ) ) . '</span>' : '<span>No numbers yet</span>' ) . '</div>'
				. '<div class="rrm-row-actions"><a href="' . esc_url( $edit ) . '">Edit</a><a href="' . esc_url( get_permalink( $p ) ) . '" target="_blank">View</a>'
				. self::act( $p->ID, 'publish' === $p->post_status ? 'draft' : 'publish', 'publish' === $p->post_status ? 'Unpublish' : 'Publish' )
				. self::act( $p->ID, 'copy', 'Duplicate' ) . self::act( $p->ID, 'trash', 'Delete', 'danger' ) . '</div></div></article>';
		}
		echo '</div>';
	}

	public static function row_action() {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		$do = isset( $_GET['do'] ) ? sanitize_key( $_GET['do'] ) : '';
		check_admin_referer( 'rrm_act_' . $id );
		if ( 'order' === $do ) {
			foreach ( array_map( 'intval', explode( ',', isset( $_GET['ids'] ) ? sanitize_text_field( wp_unslash( $_GET['ids'] ) ) : '' ) ) as $i => $pid ) {
				if ( $pid && current_user_can( 'edit_post', $pid ) && in_array( get_post_type( $pid ), array( 'rr_gig', 'rr_project' ), true ) ) {
					wp_update_post( array( 'ID' => $pid, 'menu_order' => $i ) );
				}
			}
			wp_send_json_success();
		}
		$p = get_post( $id );
		if ( ! $p || ! current_user_can( 'edit_post', $id ) || ! in_array( $p->post_type, array( 'rr_gig', 'rr_project' ), true ) ) {
			wp_die( 'Not allowed.' );
		}
		$page = 'rr_gig' === $p->post_type ? 'gigs' : 'portfolio';
		$msg  = 'Saved';
		if ( 'trash' === $do ) {
			wp_trash_post( $id );
			$msg = 'Moved to trash';
		} elseif ( in_array( $do, array( 'publish', 'draft' ), true ) ) {
			wp_update_post( array( 'ID' => $id, 'post_status' => $do ) );
			$msg = 'publish' === $do ? 'Published' : 'Unpublished (now a draft)';
		} elseif ( 'copy' === $do ) {
			$new = wp_insert_post( array( 'post_type' => $p->post_type, 'post_status' => 'draft', 'post_title' => $p->post_title . ' (copy)', 'post_content' => $p->post_content, 'post_excerpt' => $p->post_excerpt, 'menu_order' => $p->menu_order + 1 ) );
			foreach ( get_post_meta( $id ) as $k => $v ) {
				if ( 0 === strpos( $k, 'rr_' ) || 0 === strpos( $k, 'rank_math_' ) || '_thumbnail_id' === $k ) {
					update_post_meta( $new, $k, maybe_unserialize( $v[0] ) );
				}
			}
			foreach ( get_object_taxonomies( $p->post_type ) as $tx ) {
				wp_set_object_terms( $new, wp_get_object_terms( $id, $tx, array( 'fields' => 'ids' ) ), $tx );
			}
			wp_safe_redirect( self::url( $page, array( 'edit' => $new, 'rrm_msg' => 'Copy created as a draft' ) ) );
			exit;
		}
		wp_safe_redirect( self::url( $page, array( 'rrm_msg' => $msg ) ) );
		exit;
	}

	/* ---------------- shared form bits ---------------- */

	private static function field( $name, $label, $val, $args = array() ) {
		$a    = wp_parse_args( $args, array( 'type' => 'text', 'ph' => '', 'help' => '', 'rows' => 3, 'max' => 0, 'cls' => '' ) );
		$id   = 'f_' . preg_replace( '/[^a-z0-9_]/i', '_', $name );
		$cnt  = $a['max'] ? ' data-max="' . (int) $a['max'] . '"' : '';
		$html = '<label class="rrm-field ' . esc_attr( $a['cls'] ) . '" for="' . esc_attr( $id ) . '"><span>' . esc_html( $label ) . ( $a['max'] ? '<em class="rrm-count"></em>' : '' ) . '</span>';
		if ( 'textarea' === $a['type'] ) {
			$html .= '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="' . (int) $a['rows'] . '" placeholder="' . esc_attr( $a['ph'] ) . '"' . $cnt . '>' . esc_textarea( (string) $val ) . '</textarea>';
		} else {
			$html .= '<input id="' . esc_attr( $id ) . '" type="' . esc_attr( $a['type'] ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $val ) . '" placeholder="' . esc_attr( $a['ph'] ) . '"' . $cnt . ( 'number' === $a['type'] ? ' step="any" min="0"' : '' ) . '>';
		}
		if ( $a['help'] ) {
			$html .= '<small>' . esc_html( $a['help'] ) . '</small>';
		}
		echo $html . '</label>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	private static function image_picker( $name, $id, $label, $help ) {
		$src = $id ? wp_get_attachment_image_url( (int) $id, 'medium_large' ) : '';
		echo '<div class="rrm-image" data-multi="0"><span class="rrm-lab">' . esc_html( $label ) . '</span><div class="rrm-image-box' . ( $src ? ' has' : '' ) . '">' . ( $src ? '<img src="' . esc_url( $src ) . '" alt="">' : '' ) . '<button type="button" class="rrm-pick">' . ( $src ? 'Change image' : '＋ Choose or upload image' ) . '</button>' . ( $src ? '<button type="button" class="rrm-clear">Remove</button>' : '' ) . '</div><input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $id ) . '"><small>' . esc_html( $help ) . '</small></div>';
	}

	private static function terms_select( $tax, $post_id, $label, $multi = true ) {
		$all = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => false ) );
		$has = $post_id ? wp_get_post_terms( $post_id, $tax, array( 'fields' => 'ids' ) ) : array();
		echo '<div class="rrm-field"><span>' . esc_html( $label ) . '</span><div class="rrm-pills">';
		foreach ( is_array( $all ) ? $all : array() as $t ) {
			echo '<label><input type="' . ( $multi ? 'checkbox' : 'radio' ) . '" name="terms[]" value="' . (int) $t->term_id . '"' . checked( in_array( $t->term_id, (array) $has, true ), true, false ) . '><b>' . esc_html( $t->name ) . '</b></label>';
		}
		echo '</div><small><input type="text" name="new_term" placeholder="+ Add a new category" class="rrm-mini"></small></div>';
	}

	private static function seo_box( $id ) {
		$t = $id ? get_post_meta( $id, 'rank_math_title', true ) : '';
		$d = $id ? get_post_meta( $id, 'rank_math_description', true ) : '';
		$k = $id ? get_post_meta( $id, 'rank_math_focus_keyword', true ) : '';
		echo '<section class="rrm-card"><h2>Google preview (SEO)</h2><div class="rrm-serp"><cite>' . esc_html( preg_replace( '#^https?://#', '', $id ? get_permalink( $id ) : home_url( '/' ) ) ) . '</cite><b data-serp="t">' . esc_html( $t ?: ( $id ? get_the_title( $id ) : 'Your title' ) ) . '</b><p data-serp="d">' . esc_html( $d ?: 'Your description shows here.' ) . '</p></div>';
		self::field( 'seo_title', 'SEO title', $t, array( 'max' => 60, 'help' => 'Leave empty to use the gig title. Best under 60 characters.' ) );
		self::field( 'seo_desc', 'Meta description', $d, array( 'type' => 'textarea', 'rows' => 2, 'max' => 160, 'help' => 'Best 120–160 characters. Say what you deliver and for whom.' ) );
		self::field( 'seo_kw', 'Focus keyword', $k, array( 'ph' => 'e.g. local SEO expert' ) );
		echo '</section>';
	}

	private static function save_seo( $id ) {
		$map = array( 'seo_title' => 'rank_math_title', 'seo_desc' => 'rank_math_description', 'seo_kw' => 'rank_math_focus_keyword' );
		foreach ( $map as $f => $k ) {
			if ( isset( $_POST[ $f ] ) ) { // phpcs:ignore
				$v = sanitize_text_field( wp_unslash( $_POST[ $f ] ) ); // phpcs:ignore
				$v ? update_post_meta( $id, $k, $v ) : delete_post_meta( $id, $k );
			}
		}
	}

	private static function save_terms( $id, $tax ) {
		$ids = isset( $_POST['terms'] ) ? array_map( 'intval', (array) $_POST['terms'] ) : array(); // phpcs:ignore
		$new = isset( $_POST['new_term'] ) ? sanitize_text_field( wp_unslash( $_POST['new_term'] ) ) : ''; // phpcs:ignore
		if ( $new ) {
			$t = term_exists( $new, $tax ) ?: wp_insert_term( $new, $tax );
			if ( ! is_wp_error( $t ) ) {
				$ids[] = (int) $t['term_id'];
			}
		}
		wp_set_object_terms( $id, $ids, $tax );
	}

	private static function form_open( $action, $id, $back, $title ) {
		echo '<form class="rrm-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( $action, '_rrm' );
		echo '<input type="hidden" name="action" value="' . esc_attr( $action ) . '"><input type="hidden" name="id" value="' . esc_attr( (string) $id ) . '">';
		$st = $id ? get_post_status( $id ) : 'draft';
		echo '<div class="rrm-head sticky"><div><a class="rrm-back" href="' . esc_url( $back ) . '">← Back</a><h1>' . esc_html( $title ) . '</h1></div><div class="rrm-actions">'
			. ( $id ? '<a class="rrm-btn ghost" target="_blank" href="' . esc_url( 'publish' === $st ? get_permalink( $id ) : get_preview_post_link( $id ) ) . '">' . ( 'publish' === $st ? 'View live ↗' : 'Preview ↗' ) . '</a>' : '' )
			. '<button class="rrm-btn light" name="status" value="draft">Save draft</button><button class="rrm-btn" name="status" value="publish">' . ( 'publish' === $st ? 'Update' : 'Publish' ) . '</button></div></div>';
	}

	/* ---------------- gig editor ---------------- */

	private static function gig_form( $edit ) {
		$id = 'new' === $edit ? 0 : (int) $edit;
		$p  = $id ? get_post( $id ) : null;
		if ( $id && ( ! $p || 'rr_gig' !== $p->post_type ) ) {
			echo '<p>Gig not found.</p>';
			return;
		}
		$m  = function ( $k, $d = '' ) use ( $id ) { $v = $id ? get_post_meta( $id, $k, true ) : ''; return '' === $v ? $d : $v; };
		$pk = $id && class_exists( 'RR_Gigs' ) ? RR_Gigs::packages( $id ) : array();
		self::form_open( 'rrm_save_gig', $id, self::url( 'gigs' ), $id ? 'Edit gig' : 'New gig' );
		echo '<div class="rrm-layout"><div class="rrm-main">';

		echo '<section class="rrm-card"><h2><i>1</i> Gig overview</h2>';
		self::field( 'title', 'Gig title (starts with "I will…")', $p ? $p->post_title : 'I will ', array( 'max' => 80, 'cls' => 'big', 'help' => 'Like Fiverr: one clear promise, e.g. "I will do local SEO and optimize your Google Business Profile".' ) );
		self::field( 'excerpt', 'Short card text', $p ? $p->post_excerpt : '', array( 'type' => 'textarea', 'rows' => 2, 'max' => 160, 'help' => 'Shown on the gig cards. One or two sentences.' ) );
		echo '<div class="rrm-two">';
		self::field( 'rr_label', 'Category label on the page', $m( 'rr_label' ), array( 'ph' => 'e.g. Local SEO' ) );
		self::field( 'slug', 'Page address', $p ? $p->post_name : '', array( 'ph' => 'auto from title', 'help' => home_url( '/hire-me/' ) . '…' ) );
		echo '</div>';
		self::terms_select( 'rr_gig_cat', $id, 'Gig category (filter on the Gigs page)' );
		echo '</section>';

		echo '<section class="rrm-card"><h2><i>2</i> Packages &amp; pricing</h2><p class="rrm-hint">Fill only Basic for a single price. Add Standard and Premium for a 3-package table like Fiverr.</p><div class="rrm-pk">';
		$names = array( 'Basic', 'Standard', 'Premium' );
		for ( $i = 0; $i < 3; $i++ ) {
			$x = isset( $pk[ $i ] ) ? $pk[ $i ] : array();
			$v = function ( $k, $d = '' ) use ( $x ) { return isset( $x[ $k ] ) ? $x[ $k ] : $d; };
			echo '<div class="rrm-pkcol' . ( $i && ! $x ? ' off' : '' ) . '"><input type="hidden" name="pk[' . $i . '][on]" value="' . ( ! $i || $x ? '1' : '' ) . '"><div class="rrm-pkhead"><b>' . esc_html( $names[ $i ] ) . '</b>' . ( $i ? '<label class="rrm-switch"><input type="checkbox" class="rrm-pk-on"' . checked( (bool) $x, true, false ) . '><span></span></label>' : '<em>Required</em>' ) . '</div><div class="rrm-pkbody">';
			self::field( "pk[$i][name]", 'Name', $v( 'name', $names[ $i ] ) );
			echo '<div class="rrm-two">';
			self::field( "pk[$i][price]", 'Price (USD)', $v( 'price' ), array( 'type' => 'number', 'ph' => '0' ) );
			self::field( "pk[$i][days]", 'Delivery days', $v( 'days' ), array( 'type' => 'number', 'ph' => '3' ) );
			echo '</div>';
			self::field( "pk[$i][rev]", 'Revisions', $v( 'rev' ), array( 'ph' => '2 or Unlimited' ) );
			self::field( "pk[$i][desc]", 'One-line summary', $v( 'desc' ), array( 'ph' => 'What this package is for' ) );
			self::field( "pk[$i][features]", "What's included (one per line)", implode( "\n", (array) $v( 'features', array() ) ), array( 'type' => 'textarea', 'rows' => 6 ) );
			echo '</div></div>';
		}
		$rate = class_exists( 'RR_Gigs' ) ? (float) RR_Gigs::opt( 'rate', '122' ) : 122;
		echo '</div><p class="rrm-hint">Direct orders are charged in taka at ৳' . esc_html( (string) $rate ) . ' per $1 (change it in Settings). Up to ৳' . esc_html( number_format( (float) ( class_exists( 'RR_Gigs' ) ? RR_Gigs::opt( 'limit', '20000' ) : 20000 ) ) ) . ' clients see bKash / Nagad / Rocket / Upay; above that, bank transfer or Payoneer.</p></section>';

		echo '<section class="rrm-card"><h2><i>3</i> About this gig</h2>';
		wp_editor( $p ? $p->post_content : '', 'rrm_content', array( 'textarea_name' => 'content', 'textarea_rows' => 12, 'media_buttons' => true ) );
		echo '</section>';

		echo '<section class="rrm-card"><h2><i>4</i> Trust &amp; platforms</h2><div class="rrm-two">';
		self::field( 'rr_rating', 'Rating', $m( 'rr_rating', '5.0' ) );
		self::field( 'rr_reviews', 'Number of reviews (empty to hide)', $m( 'rr_reviews' ) );
		echo '</div><label class="rrm-field"><span>Platform badge</span><select name="rr_platform">';
		foreach ( array( '' => 'None', 'Fiverr' => 'Fiverr', 'Upwork' => 'Upwork' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $m( 'rr_platform' ), $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></label><div class="rrm-two">';
		self::field( 'rr_fiverr', 'Fiverr gig link', $m( 'rr_fiverr' ), array( 'type' => 'url', 'ph' => 'https://www.fiverr.com/…' ) );
		self::field( 'rr_upwork', 'Upwork project link', $m( 'rr_upwork' ), array( 'type' => 'url', 'ph' => 'https://www.upwork.com/services/…' ) );
		echo '</div>';
		self::field( 'rr_quote', 'Client review (quote)', $m( 'rr_quote' ), array( 'type' => 'textarea', 'rows' => 3 ) );
		echo '</section>';
		self::seo_box( $id );
		echo '</div><aside class="rrm-side">';

		echo '<section class="rrm-card"><h2>Cover image</h2>';
		self::image_picker( 'thumb', $id ? get_post_thumbnail_id( $id ) : 0, '', '1280 × 800 px works best (like Fiverr).' );
		echo '</section><section class="rrm-card"><h2>Results image</h2>';
		self::image_picker( 'rr_proof', (int) $m( 'rr_proof', 0 ), '', 'Optional screenshot of results (e.g. Search Console).' );
		echo '</section><section class="rrm-card"><h2>Order on the Gigs page</h2>';
		self::field( 'menu_order', 'Position (1 = first)', $p ? $p->menu_order + 1 : 1, array( 'type' => 'number' ) );
		echo '<p class="rrm-hint">Or drag cards in the gig list.</p></section>';
		if ( $id ) {
			echo '<section class="rrm-card subtle"><a href="' . esc_url( admin_url( 'post.php?post=' . $id . '&action=edit&classic=1' ) ) . '">Open in the advanced WordPress editor</a></section>';
		}
		echo '</aside></div></form>';
	}

	public static function save_gig() {
		check_admin_referer( 'rrm_save_gig', '_rrm' );
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		if ( ! current_user_can( $id ? 'edit_post' : 'edit_posts', $id ) ) {
			wp_die( 'Not allowed.' );
		}
		$data = array(
			'post_type'    => 'rr_gig',
			'post_title'   => sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) ),
			'post_excerpt' => sanitize_textarea_field( wp_unslash( $_POST['excerpt'] ?? '' ) ),
			'post_content' => wp_kses_post( wp_unslash( $_POST['content'] ?? '' ) ),
			'post_status'  => 'publish' === ( $_POST['status'] ?? '' ) ? 'publish' : 'draft',
			'menu_order'   => max( 0, (int) ( $_POST['menu_order'] ?? 1 ) - 1 ),
		);
		$slug = sanitize_title( wp_unslash( $_POST['slug'] ?? '' ) );
		if ( $slug ) {
			$data['post_name'] = $slug;
		}
		if ( $id ) {
			$data['ID'] = $id;
			wp_update_post( $data );
		} else {
			$id = wp_insert_post( $data );
		}
		foreach ( array( 'rr_label', 'rr_platform', 'rr_rating', 'rr_reviews' ) as $k ) {
			update_post_meta( $id, $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ?? '' ) ) );
		}
		foreach ( array( 'rr_fiverr', 'rr_upwork' ) as $k ) {
			update_post_meta( $id, $k, esc_url_raw( wp_unslash( $_POST[ $k ] ?? '' ) ) );
		}
		update_post_meta( $id, 'rr_quote', sanitize_textarea_field( wp_unslash( $_POST['rr_quote'] ?? '' ) ) );
		update_post_meta( $id, 'rr_proof', (int) ( $_POST['rr_proof'] ?? 0 ) ?: '' );
		$thumb = (int) ( $_POST['thumb'] ?? 0 );
		$thumb ? set_post_thumbnail( $id, $thumb ) : delete_post_thumbnail( $id );
		$pk = array();
		foreach ( isset( $_POST['pk'] ) ? (array) wp_unslash( $_POST['pk'] ) : array() as $x ) { // phpcs:ignore
			if ( empty( $x['on'] ) || empty( $x['name'] ) || '' === ( $x['price'] ?? '' ) ) {
				continue;
			}
			$rev  = trim( sanitize_text_field( $x['rev'] ?? '' ) );
			$pk[] = array(
				'name'     => sanitize_text_field( $x['name'] ),
				'price'    => (float) $x['price'],
				'days'     => max( 1, (int) ( $x['days'] ?? 1 ) ),
				'rev'      => is_numeric( $rev ) ? (int) $rev : ( $rev ?: '1' ),
				'desc'     => sanitize_text_field( $x['desc'] ?? '' ),
				'features' => array_values( array_filter( array_map( 'sanitize_text_field', preg_split( '/\r?\n/', (string) ( $x['features'] ?? '' ) ) ) ) ),
			);
		}
		update_post_meta( $id, 'rr_packages', wp_json_encode( $pk ) );
		self::save_terms( $id, 'rr_gig_cat' );
		self::save_seo( $id );
		wp_safe_redirect( self::url( 'gigs', array( 'edit' => $id, 'rrm_msg' => 'publish' === $data['post_status'] ? 'Gig saved and live' : 'Draft saved' ) ) );
		exit;
	}

	/* ---------------- project editor ---------------- */

	private static function project_form( $edit ) {
		$id = 'new' === $edit ? 0 : (int) $edit;
		$p  = $id ? get_post( $id ) : null;
		if ( $id && ( ! $p || 'rr_project' !== $p->post_type ) ) {
			echo '<p>Case study not found.</p>';
			return;
		}
		$m = function ( $k, $d = '' ) use ( $id ) { $v = $id ? get_post_meta( $id, $k, true ) : ''; return '' === $v ? $d : $v; };
		self::form_open( 'rrm_save_project', $id, self::url( 'portfolio' ), $id ? 'Edit case study' : 'New case study' );
		echo '<div class="rrm-layout"><div class="rrm-main"><section class="rrm-card"><h2><i>1</i> Card</h2>';
		self::field( 'title', 'Case study title', $p ? $p->post_title : '', array( 'cls' => 'big', 'max' => 80, 'ph' => 'e.g. 931K Google clicks for a travel booking brand' ) );
		self::field( 'excerpt', 'Short card text', $p ? $p->post_excerpt : '', array( 'type' => 'textarea', 'rows' => 2, 'max' => 180 ) );
		echo '<div class="rrm-two">';
		self::field( 'rr_tag', 'Card label', $m( 'rr_tag' ), array( 'ph' => 'e.g. Local SEO' ) );
		self::field( 'rr_industry', 'Industry', $m( 'rr_industry' ), array( 'ph' => 'e.g. Tree service company' ) );
		echo '</div></section>';

		echo '<section class="rrm-card"><h2><i>2</i> Key numbers</h2><p class="rrm-hint">The big results on the card and the page. Example: 931K · Google clicks.</p><div class="rrm-metrics">';
		$rows = array_filter( array_map( 'trim', preg_split( '/\r?\n/', (string) $m( 'rr_metrics' ) ) ) );
		$rows = $rows ?: array( '' );
		foreach ( $rows as $r ) {
			$x = array_map( 'trim', explode( '|', $r . '|' ) );
			echo '<div class="rrm-metric"><input name="mv[]" value="' . esc_attr( $x[0] ) . '" placeholder="931K"><input name="ml[]" value="' . esc_attr( $x[1] ) . '" placeholder="Google clicks in 16 months"><button type="button" class="rrm-x" aria-label="Remove">×</button></div>';
		}
		echo '</div><button type="button" class="rrm-btn light small rrm-add-metric">+ Add number</button></section>';

		echo '<section class="rrm-card"><h2><i>3</i> Full case study</h2>';
		wp_editor( $p ? $p->post_content : '', 'rrm_content', array( 'textarea_name' => 'content', 'textarea_rows' => 14, 'media_buttons' => true ) );
		echo '</section><section class="rrm-card"><h2><i>4</i> Service &amp; order button</h2><div class="rrm-two">';
		$services = array( '' => '—', 'technical-seo' => 'Technical SEO', 'local-seo' => 'Local SEO', 'ai-seo' => 'AI Search (GEO & AEO)', 'woocommerce-seo' => 'WooCommerce SEO', 'wordpress-web-design' => 'WordPress Web Design', 'seo-consulting' => 'SEO Consulting' );
		echo '<label class="rrm-field"><span>Service</span><select name="rr_service">';
		foreach ( $services as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $m( 'rr_service' ), $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select><small>Shows this case study on that service page.</small></label>';
		self::field( 'rr_order_label', 'Button text', $m( 'rr_order_label', 'Get results like this' ) );
		echo '</div><div class="rrm-two">';
		self::field( 'rr_order_url', 'Button link', $m( 'rr_order_url', '/hire-me/' ) );
		self::field( 'rr_service_url', 'Service page link', $m( 'rr_service_url' ), array( 'ph' => '/services/local-seo/' ) );
		echo '</div></section>';
		self::seo_box( $id );
		echo '</div><aside class="rrm-side"><section class="rrm-card"><h2>Card image</h2>';
		self::image_picker( 'thumb', $id ? get_post_thumbnail_id( $id ) : 0, '', 'A results screenshot works best.' );
		echo '</section><section class="rrm-card"><h2>Gallery</h2><div class="rrm-gallery">';
		$gal = array_filter( array_map( 'intval', explode( ',', (string) $m( 'rr_gallery' ) ) ) );
		foreach ( $gal as $g ) {
			echo '<span data-id="' . (int) $g . '"><img src="' . esc_url( (string) wp_get_attachment_image_url( $g, 'thumbnail' ) ) . '" alt=""><button type="button">×</button></span>';
		}
		echo '</div><input type="hidden" name="rr_gallery" value="' . esc_attr( implode( ',', $gal ) ) . '"><button type="button" class="rrm-btn light small rrm-gal-add">+ Add images</button></section>';
		self::terms_select( 'rr_project_type', $id, 'Project type' );
		echo '<section class="rrm-card"><h2>Order on the Portfolio page</h2>';
		self::field( 'menu_order', 'Position (1 = first)', $p ? $p->menu_order + 1 : 1, array( 'type' => 'number' ) );
		echo '</section>';
		if ( $id ) {
			echo '<section class="rrm-card subtle"><a href="' . esc_url( admin_url( 'post.php?post=' . $id . '&action=edit&classic=1' ) ) . '">Open in the advanced WordPress editor</a></section>';
		}
		echo '</aside></div></form>';
	}

	public static function save_project() {
		check_admin_referer( 'rrm_save_project', '_rrm' );
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		if ( ! current_user_can( $id ? 'edit_post' : 'edit_posts', $id ) ) {
			wp_die( 'Not allowed.' );
		}
		$data = array(
			'post_type'    => 'rr_project',
			'post_title'   => sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) ),
			'post_excerpt' => sanitize_textarea_field( wp_unslash( $_POST['excerpt'] ?? '' ) ),
			'post_content' => wp_kses_post( wp_unslash( $_POST['content'] ?? '' ) ),
			'post_status'  => 'publish' === ( $_POST['status'] ?? '' ) ? 'publish' : 'draft',
			'menu_order'   => max( 0, (int) ( $_POST['menu_order'] ?? 1 ) - 1 ),
		);
		if ( $id ) {
			$data['ID'] = $id;
			wp_update_post( $data );
		} else {
			$id = wp_insert_post( $data );
		}
		foreach ( array( 'rr_tag', 'rr_industry', 'rr_service', 'rr_order_label' ) as $k ) {
			update_post_meta( $id, $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ?? '' ) ) );
		}
		foreach ( array( 'rr_order_url', 'rr_service_url' ) as $k ) {
			$v = trim( (string) wp_unslash( $_POST[ $k ] ?? '' ) );
			update_post_meta( $id, $k, 0 === strpos( $v, '/' ) ? sanitize_text_field( $v ) : esc_url_raw( $v ) );
		}
		$mv    = array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['mv'] ?? array() ) ); // phpcs:ignore
		$ml    = array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['ml'] ?? array() ) ); // phpcs:ignore
		$lines = array();
		foreach ( $mv as $i => $v ) {
			if ( '' !== trim( $v ) ) {
				$lines[] = trim( $v ) . ' | ' . trim( $ml[ $i ] ?? '' );
			}
		}
		update_post_meta( $id, 'rr_metrics', implode( "\n", $lines ) );
		update_post_meta( $id, 'rr_gallery', implode( ',', array_filter( array_map( 'intval', explode( ',', (string) ( $_POST['rr_gallery'] ?? '' ) ) ) ) ) );
		$thumb = (int) ( $_POST['thumb'] ?? 0 );
		$thumb ? set_post_thumbnail( $id, $thumb ) : delete_post_thumbnail( $id );
		self::save_terms( $id, 'rr_project_type' );
		self::save_seo( $id );
		wp_safe_redirect( self::url( 'portfolio', array( 'edit' => $id, 'rrm_msg' => 'publish' === $data['post_status'] ? 'Case study saved and live' : 'Draft saved' ) ) );
		exit;
	}

	/* ---------------- settings ---------------- */

	private static function settings() {
		$gs = get_option( 'rr_gigs_settings', array() );
		$gk = wp_parse_args( get_option( 'rr_growth_kit', array() ), class_exists( 'RR_Growth_Kit' ) ? RR_Growth_Kit::defaults() : array() );
		$g  = function ( $k, $d = '' ) use ( $gs ) { return isset( $gs[ $k ] ) && '' !== $gs[ $k ] ? $gs[ $k ] : $d; };
		$k  = function ( $x ) use ( $gk ) { return $gk[ $x ] ?? ''; };
		echo '<form class="rrm-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'rrm_save_settings', '_rrm' );
		echo '<input type="hidden" name="action" value="rrm_save_settings"><div class="rrm-head sticky"><div><h1>Settings &amp; tracking</h1><p>Payments, contact buttons, popup and every tracking tool.</p></div><div class="rrm-actions"><button class="rrm-btn">Save settings</button></div></div><div class="rrm-layout"><div class="rrm-main">';

		echo '<section class="rrm-card" id="tracking"><h2>📊 Tracking</h2><p class="rrm-hint">Paste only the IDs. Every click on WhatsApp, call, gigs, payment, booking, Fiverr, Upwork and forms is sent to all the tools you turn on.</p><div class="rrm-two">';
		self::field( 'gk[ga4]', 'Google Analytics 4 measurement ID', $k( 'ga4' ), array( 'ph' => 'G-XXXXXXXXXX', 'help' => 'Analytics › Admin › Data streams › your site.' ) );
		self::field( 'gk[gtm]', 'Google Tag Manager container ID', $k( 'gtm' ), array( 'ph' => 'GTM-XXXXXXX', 'help' => 'Optional. If GA4 is inside GTM, leave the GA4 field empty.' ) );
		self::field( 'gk[clarity]', 'Microsoft Clarity project ID', $k( 'clarity' ), array( 'ph' => 'abcd1234ef', 'help' => 'Clarity › Settings › Overview.' ) );
		self::field( 'gk[gsc]', 'Search Console verification code', $k( 'gsc' ), array( 'ph' => 'content="…" value only', 'help' => 'Search Console › HTML tag method.' ) );
		self::field( 'gk[meta_pixel]', 'Meta (Facebook) Pixel ID', $k( 'meta_pixel' ), array( 'ph' => '123456789012345' ) );
		self::field( 'gk[linkedin]', 'LinkedIn Insight partner ID', $k( 'linkedin' ), array( 'ph' => '1234567' ) );
		echo '</div>';
		self::toggle( 'gk[consent]', 'Ask for cookie consent first (recommended for EU / UK visitors)', '1' === $k( 'consent' ) );
		echo '</section>';

		echo '<section class="rrm-card"><h2>💬 Lead capture</h2><div class="rrm-two">';
		self::field( 'gk[whatsapp]', 'WhatsApp number (country code, digits)', $k( 'whatsapp' ), array( 'ph' => '8801…' ) );
		self::field( 'gk[phone]', 'Phone for the call button', $k( 'phone' ) );
		echo '</div>';
		self::field( 'gk[wa_text]', 'WhatsApp first message', $k( 'wa_text' ) );
		self::toggle( 'gk[bar]', 'Show WhatsApp / call buttons and the mobile action bar', '1' === $k( 'bar' ) );
		self::toggle( 'gk[popup]', 'Show the free SEO audit popup (exit intent or after 35 s, once a week)', '1' === $k( 'popup' ) );
		echo '<div class="rrm-two">';
		self::field( 'gk[popup_url]', 'Popup button link', $k( 'popup_url' ) );
		self::field( 'gk[popup_skip]', 'Pages without the popup', $k( 'popup_skip' ), array( 'help' => 'Comma separated paths.' ) );
		echo '</div></section>';

		echo '<section class="rrm-card"><h2>🔀 Redirects</h2>';
		self::field( 'gk[redirects]', 'Old address → new address (one per line, separated by a space)', $k( 'redirects' ), array( 'type' => 'textarea', 'rows' => 8, 'help' => 'Dead addresses ending in -2 are fixed automatically.' ) );
		echo '</section></div><aside class="rrm-side">';

		echo '<section class="rrm-card"><h2>💳 Payments</h2>';
		self::field( 'gs[rate]', 'Taka per $1 for direct orders', $g( 'rate', '122' ), array( 'type' => 'number' ) );
		self::field( 'gs[limit]', 'Mobile banking limit (৳)', $g( 'limit', '20000' ), array( 'type' => 'number', 'help' => 'Above this, only bank transfer and Payoneer are shown.' ) );
		self::field( 'gs[payoneer]', 'Payoneer payment link (optional)', $g( 'payoneer' ), array( 'help' => 'Empty = the button opens the contact page.' ) );
		self::field( 'gs[thanks]', 'Thank-you page after payment', $g( 'thanks', '/thank-you/' ) );
		echo '<a class="rrm-link" href="' . esc_url( admin_url( 'admin.php?page=nexora-pay&tab=gateways' ) ) . '">Payment methods (Nexora Pay) →</a></section>';

		echo '<section class="rrm-card"><h2>👤 Seller profile on gig pages</h2>';
		self::field( 'gs[name]', 'Name', $g( 'name', 'Rysul Islam Riak' ) );
		self::field( 'gs[seller]', 'Tagline', $g( 'seller' ) );
		self::field( 'gs[stats]', 'Stats line', $g( 'stats' ) );
		self::field( 'gs[photo]', 'Photo URL', $g( 'photo' ) );
		self::field( 'gs[fiverr]', 'Fiverr profile', $g( 'fiverr' ) );
		self::field( 'gs[upwork]', 'Upwork profile', $g( 'upwork' ) );
		echo '</section></aside></div></form>';
	}

	private static function toggle( $name, $label, $on ) {
		echo '<label class="rrm-toggle"><input type="hidden" name="' . esc_attr( $name ) . '" value="0"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . checked( $on, true, false ) . '><span></span>' . esc_html( $label ) . '</label>';
	}

	public static function save_settings() {
		check_admin_referer( 'rrm_save_settings', '_rrm' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		$gs = array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['gs'] ?? array() ) ); // phpcs:ignore
		update_option( 'rr_gigs_settings', array_merge( (array) get_option( 'rr_gigs_settings', array() ), $gs ) );
		$in  = (array) wp_unslash( $_POST['gk'] ?? array() ); // phpcs:ignore
		$out = (array) get_option( 'rr_growth_kit', array() );
		foreach ( $in as $key => $v ) {
			$key = sanitize_key( $key );
			if ( 'redirects' === $key ) {
				$out[ $key ] = sanitize_textarea_field( $v );
			} elseif ( 'gsc' === $key && preg_match( '/content=["\']([^"\']+)/', $v, $mm ) ) {
				$out[ $key ] = sanitize_text_field( $mm[1] ); // accept the whole meta tag too
			} else {
				$out[ $key ] = sanitize_text_field( $v );
			}
		}
		update_option( 'rr_growth_kit', $out );
		wp_safe_redirect( self::url( 'settings', array( 'rrm_msg' => 'Settings saved' ) ) );
		exit;
	}

	/* ---------------- styles & scripts ---------------- */

	private static function css() {
		return <<<'CSS'
.rrm{--ink:#0F172A;--slate:#64748B;--line:#E6EBF4;--blue:#2D5BFF;--navy:#0B1530;--gold:#F2A93B;margin:0 0 0 -20px;padding:0 28px 60px;font-family:Inter,-apple-system,"Segoe UI",system-ui,sans-serif;color:var(--ink);background:#F5F7FC;min-height:calc(100vh - 32px)}
.rrm *{box-sizing:border-box}.rrm h1{font-size:24px;font-weight:800;margin:0;letter-spacing:-.01em;padding:0}.rrm h2{font-size:15.5px;font-weight:700;margin:0 0 16px;display:flex;align-items:center;gap:10px}
.rrm h2 i{font-style:normal;width:24px;height:24px;border-radius:8px;background:#EEF3FF;color:var(--blue);display:grid;place-items:center;font-size:12.5px}
.rrm p{color:var(--slate);margin:4px 0 0;font-size:13.5px}
.rrm-top{display:flex;align-items:center;gap:24px;margin:0 -28px 26px;padding:14px 28px;background:var(--navy);color:#fff;position:sticky;top:32px;z-index:20}
.rrm-brand{display:flex;align-items:center;gap:12px}.rrm-brand span{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#5B8CFF,#2D5BFF);display:grid;place-items:center;font-weight:800;font-size:17px}
.rrm-brand b{display:block;font-size:15px}.rrm-brand small{color:#9FB0D0;font-size:12px}
.rrm-top nav{display:flex;gap:4px;margin-right:auto}.rrm-top nav a{color:#C7D2EA;text-decoration:none;padding:9px 14px;border-radius:9px;font-weight:600;font-size:13.5px}
.rrm-top nav a:hover{background:rgba(255,255,255,.07);color:#fff}.rrm-top nav a.on{background:rgba(91,140,255,.22);color:#fff}
.rrm-btn{display:inline-flex;align-items:center;gap:6px;border:0;cursor:pointer;background:var(--blue);color:#fff!important;text-decoration:none;padding:11px 18px;border-radius:11px;font:700 13.5px/1 Inter,system-ui,sans-serif;box-shadow:0 8px 18px -10px rgba(45,91,255,.8);transition:.15s}
.rrm-btn:hover{filter:brightness(1.08);transform:translateY(-1px)}.rrm-btn.light{background:#fff;color:var(--ink)!important;border:1px solid var(--line);box-shadow:none}
.rrm-btn.ghost{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16);box-shadow:none}.rrm-head .rrm-btn.ghost{background:#fff;color:var(--ink)!important;border:1px solid var(--line)}
.rrm-btn.small{padding:8px 12px;font-size:12.5px}
.rrm-toast{position:fixed;right:24px;bottom:24px;z-index:99999;background:#0F172A;color:#fff;padding:13px 18px;border-radius:12px;font-weight:600;box-shadow:0 20px 40px -15px rgba(0,0,0,.5);animation:rrmt 4s forwards}
@keyframes rrmt{0%{opacity:0;transform:translateY(10px)}8%,85%{opacity:1;transform:none}100%{opacity:0;visibility:hidden}}
.rrm-hero{display:flex;justify-content:space-between;align-items:center;gap:20px;background:linear-gradient(135deg,#0B1530,#1E3A8A);color:#fff;border-radius:20px;padding:30px 32px;margin-bottom:20px}
.rrm-hero h1{color:#fff;font-size:26px}.rrm-hero p{color:#C7D2EA;font-size:14.5px;max-width:560px}
.rrm-actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.rrm-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px}
.rrm-stat{background:#fff;border:1px solid var(--line);border-radius:16px;padding:18px 20px;text-decoration:none;color:var(--ink);transition:.15s}.rrm-stat:hover{transform:translateY(-2px);box-shadow:0 16px 30px -20px rgba(15,23,42,.35)}
.rrm-stat b{display:block;font-size:28px;font-weight:800}.rrm-stat span{display:block;font-weight:600;margin-top:4px}.rrm-stat small{color:var(--slate);font-size:12.5px}
.rrm-cols{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.rrm-card{background:#fff;border:1px solid var(--line);border-radius:16px;padding:22px 22px 20px;margin-bottom:16px}.rrm-card.subtle{background:transparent;border-style:dashed;padding:14px 18px}.rrm-card.subtle a{color:var(--slate);font-size:13px}
.rrm-checks{list-style:none;margin:0 0 14px;padding:0}.rrm-checks li{display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--line);font-weight:600;font-size:14px}
.rrm-checks i{font-style:normal;width:22px;height:22px;border-radius:50%;display:grid;place-items:center;background:#F1F5F9;color:#94A3B8;font-size:12px}.rrm-checks li.ok i{background:#DCFCE7;color:#15803D}
.rrm-checks span{margin-left:auto;font-size:12.5px;color:#94A3B8;font-weight:500}.rrm-checks li.ok span{color:#15803D}
.rrm-link{color:var(--blue);font-weight:600;text-decoration:none;font-size:13.5px;display:inline-block;margin-top:6px}
.rrm-quick{display:grid;grid-template-columns:1fr 1fr;gap:10px}.rrm-quick a{padding:13px 14px;border:1px solid var(--line);border-radius:12px;text-decoration:none;color:var(--ink);font-weight:600;font-size:13.5px}.rrm-quick a:hover{border-color:#C9D6FF;color:var(--blue)}
.rrm-head{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:18px}
.rrm-head.sticky{position:sticky;top:96px;z-index:15;background:rgba(245,247,252,.94);backdrop-filter:blur(8px);padding:12px 0;margin-top:-12px}
.rrm-back{color:var(--slate);text-decoration:none;font-size:13px;font-weight:600}
.rrm-search{border:1px solid var(--line)!important;border-radius:11px!important;padding:9px 14px!important;min-width:240px;font-size:14px!important}
.rrm-chips{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px}.rrm-chips button{border:1px solid var(--line);background:#fff;border-radius:999px;padding:8px 14px;font-weight:600;font-size:13px;cursor:pointer;color:var(--ink)}
.rrm-chips button.on{background:var(--navy);border-color:var(--navy);color:#fff}
.rrm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px}
.rrm-item{position:relative;background:#fff;border:1px solid var(--line);border-radius:16px;overflow:hidden;transition:.15s;display:flex;flex-direction:column}
.rrm-item:hover{box-shadow:0 18px 34px -22px rgba(15,23,42,.4);border-color:#D5DEEE}.rrm-item.drag{opacity:.4}.rrm-item.over{outline:2px dashed var(--blue)}
.rrm-drag{position:absolute;top:10px;left:10px;z-index:3;background:rgba(255,255,255,.92);border-radius:8px;width:28px;height:28px;display:grid;place-items:center;cursor:grab;color:#475569;font-size:16px}
.rrm-thumb{display:block;aspect-ratio:16/10;background:#EEF2F8;position:relative;overflow:hidden}.rrm-thumb img{width:100%;height:100%;object-fit:cover;display:block}
.rrm-thumb em{position:absolute;inset:0;display:grid;place-items:center;color:#94A3B8;font-style:normal;font-size:13px}
.rrm-badge{position:absolute;top:10px;right:10px;font-style:normal;font-size:11px;font-weight:700;padding:5px 9px;border-radius:999px;background:#fff;color:var(--ink)}
.rrm-badge.fiverr{background:#1DBF73;color:#fff}.rrm-badge.upwork{background:#14A800;color:#fff}.rrm-badge.draft{right:auto;left:46px;background:#FEF3C7;color:#92400E}
.rrm-body{padding:14px 16px 12px;display:flex;flex-direction:column;gap:6px;flex:1}.rrm-body small{color:var(--blue);font-weight:700;font-size:11.5px;text-transform:uppercase;letter-spacing:.06em}
.rrm-title{color:var(--ink);text-decoration:none;font-weight:700;font-size:14.5px;line-height:1.4}.rrm-title:hover{color:var(--blue)}
.rrm-meta{display:flex;gap:14px;font-size:13px;color:var(--slate)}.rrm-meta b{color:var(--ink)}
.rrm-row-actions{display:flex;gap:4px;margin-top:auto;padding-top:10px;border-top:1px solid var(--line);flex-wrap:wrap}
.rrm-row-actions a{font-size:12.5px;font-weight:600;color:#475569;text-decoration:none;padding:6px 8px;border-radius:7px}.rrm-row-actions a:hover{background:#F1F5F9;color:var(--blue)}.rrm-row-actions a.danger:hover{background:#FEE2E2;color:#B91C1C}
.rrm-layout{display:grid;grid-template-columns:1fr 330px;gap:18px;align-items:start}.rrm-side{position:sticky;top:170px}
.rrm-field{display:block;margin-bottom:14px}.rrm-field>span{display:flex;justify-content:space-between;font-weight:600;font-size:13px;margin-bottom:6px}
.rrm-field input[type=text],.rrm-field input[type=url],.rrm-field input[type=number],.rrm-field input:not([type]),.rrm-field textarea,.rrm-field select,.rrm-metric input,.rrm-mini{width:100%;border:1px solid #D7DEEA!important;border-radius:10px!important;padding:10px 12px!important;font-size:14px!important;background:#fff;box-shadow:none!important;max-width:none}
.rrm-field input:focus,.rrm-field textarea:focus,.rrm-field select:focus,.rrm-metric input:focus{border-color:var(--blue)!important;box-shadow:0 0 0 3px rgba(45,91,255,.15)!important;outline:0}
.rrm-field.big input{font-size:18px!important;font-weight:700;padding:13px 14px!important}
.rrm-field small,.rrm-image small{display:block;color:#94A3B8;font-size:12px;margin-top:5px}
.rrm-count{font-style:normal;font-weight:500;color:#94A3B8}.rrm-count.over{color:#DC2626}
.rrm-two{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.rrm-hint{background:#F5F8FF;border-radius:10px;padding:10px 12px;font-size:13px!important;margin:0 0 14px!important}
.rrm-pills{display:flex;flex-wrap:wrap;gap:8px}.rrm-pills label{cursor:pointer}.rrm-pills input{display:none}
.rrm-pills b{display:inline-block;padding:8px 13px;border:1px solid var(--line);border-radius:999px;font-size:13px;font-weight:600}.rrm-pills input:checked+b{background:var(--navy);color:#fff;border-color:var(--navy)}
.rrm-mini{margin-top:8px;max-width:240px!important;padding:7px 10px!important;font-size:13px!important}
.rrm-pk{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.rrm-pkcol{border:1px solid var(--line);border-radius:14px;overflow:hidden;transition:.2s}.rrm-pkcol.off .rrm-pkbody{opacity:.35;pointer-events:none}
.rrm-pkhead{display:flex;justify-content:space-between;align-items:center;padding:12px 14px;background:#F8FAFD;border-bottom:1px solid var(--line)}.rrm-pkhead em{font-style:normal;font-size:11.5px;color:var(--slate)}
.rrm-pkbody{padding:14px 14px 2px}
.rrm-switch{position:relative;width:38px;height:22px;display:inline-block}.rrm-switch input{display:none}.rrm-switch span{position:absolute;inset:0;background:#CBD5E1;border-radius:999px;cursor:pointer;transition:.2s}
.rrm-switch span:after{content:"";position:absolute;width:16px;height:16px;left:3px;top:3px;background:#fff;border-radius:50%;transition:.2s}.rrm-switch input:checked+span{background:var(--blue)}.rrm-switch input:checked+span:after{left:19px}
.rrm-toggle{display:flex;align-items:center;gap:12px;padding:10px 0;font-weight:600;font-size:13.5px;cursor:pointer}.rrm-toggle input[type=checkbox]{display:none}
.rrm-toggle span{flex:none;position:relative;width:38px;height:22px;background:#CBD5E1;border-radius:999px;transition:.2s}.rrm-toggle span:after{content:"";position:absolute;width:16px;height:16px;left:3px;top:3px;background:#fff;border-radius:50%;transition:.2s}
.rrm-toggle input:checked+span{background:var(--blue)}.rrm-toggle input:checked+span:after{left:19px}
.rrm-image-box{position:relative;border:2px dashed #D7DEEA;border-radius:14px;min-height:150px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;overflow:hidden;background:#FAFBFE}
.rrm-image-box.has{border-style:solid;padding:0;background:#fff}.rrm-image-box img{width:100%;display:block}
.rrm-image-box button{border:0;background:#fff;border-radius:9px;padding:8px 12px;font-weight:600;cursor:pointer;box-shadow:0 2px 8px rgba(15,23,42,.12);font-size:13px}
.rrm-image-box.has button{position:absolute;bottom:10px}.rrm-image-box.has .rrm-pick{left:10px}.rrm-image-box.has .rrm-clear{right:10px;color:#B91C1C}
.rrm-metric{display:grid;grid-template-columns:140px 1fr 36px;gap:8px;margin-bottom:8px}
.rrm-x{border:1px solid var(--line);background:#fff;border-radius:9px;cursor:pointer;font-size:18px;color:#94A3B8}.rrm-x:hover{color:#B91C1C}
.rrm-gallery{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px}.rrm-gallery span{position:relative}.rrm-gallery img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:9px;display:block}
.rrm-gallery button{position:absolute;top:4px;right:4px;border:0;background:#fff;border-radius:50%;width:22px;height:22px;cursor:pointer;font-size:14px;line-height:1}
.rrm-serp{border:1px solid var(--line);border-radius:12px;padding:14px 16px;margin-bottom:16px;font-family:Arial,sans-serif}.rrm-serp cite{color:#4D5156;font-size:12.5px;font-style:normal}
.rrm-serp b{display:block;color:#1A0DAB;font-size:18px;font-weight:400;margin:4px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rrm-serp p{color:#4D5156;font-size:13.5px;margin:0;line-height:1.5}
.rrm .wp-editor-wrap{border-radius:10px;overflow:hidden}
@media(max-width:1200px){.rrm-layout{grid-template-columns:1fr}.rrm-side{position:static}.rrm-pk{grid-template-columns:1fr}.rrm-stats{grid-template-columns:1fr 1fr}}
@media(max-width:782px){.rrm{margin-left:-10px;padding:0 14px 40px}.rrm-top{margin:0 -14px 18px;padding:12px 14px;top:46px;flex-wrap:wrap;gap:10px}.rrm-top nav{order:3;width:100%;overflow-x:auto}.rrm-two,.rrm-cols{grid-template-columns:1fr}.rrm-head{flex-direction:column;align-items:stretch}.rrm-head.sticky{top:46px;position:static}.rrm-hero{flex-direction:column;align-items:flex-start}}
CSS;
	}

	private static function js() {
		$order = wp_create_nonce( 'rrm_act_0' );
		return 'jQuery(function($){'
			// image pickers
			. '$(document).on("click",".rrm-pick",function(e){e.preventDefault();var w=$(this).closest(".rrm-image"),f=wp.media({title:"Choose image",library:{type:"image"},multiple:false});f.on("select",function(){var a=f.state().get("selection").first().toJSON(),u=(a.sizes&&(a.sizes.medium_large||a.sizes.large||a.sizes.full)||a).url;w.find("input[type=hidden]").val(a.id);w.find(".rrm-image-box").addClass("has").html("<img src=\'"+u+"\' alt=\'\'><button type=\'button\' class=\'rrm-pick\'>Change image</button><button type=\'button\' class=\'rrm-clear\'>Remove</button>")});f.open()});'
			. '$(document).on("click",".rrm-clear",function(e){e.preventDefault();var w=$(this).closest(".rrm-image");w.find("input[type=hidden]").val("");w.find(".rrm-image-box").removeClass("has").html("<button type=\'button\' class=\'rrm-pick\'>＋ Choose or upload image</button>")});'
			// gallery
			. 'function gal(){var ids=$(".rrm-gallery span").map(function(){return $(this).data("id")}).get();$("input[name=rr_gallery]").val(ids.join(","))}'
			. '$(".rrm-gal-add").on("click",function(){var f=wp.media({title:"Add images",library:{type:"image"},multiple:true});f.on("select",function(){f.state().get("selection").each(function(m){var a=m.toJSON(),u=(a.sizes&&a.sizes.thumbnail||a).url;$(".rrm-gallery").append("<span data-id=\'"+a.id+"\'><img src=\'"+u+"\' alt=\'\'><button type=\'button\'>×</button></span>")});gal()});f.open()});'
			. '$(document).on("click",".rrm-gallery button",function(){$(this).parent().remove();gal()});'
			// metrics
			. '$(".rrm-add-metric").on("click",function(){$(".rrm-metrics").append("<div class=\'rrm-metric\'><input name=\'mv[]\' placeholder=\'931K\'><input name=\'ml[]\' placeholder=\'Google clicks in 16 months\'><button type=\'button\' class=\'rrm-x\'>×</button></div>")});'
			. '$(document).on("click",".rrm-metric .rrm-x",function(){if($(".rrm-metric").length>1)$(this).parent().remove();else $(this).siblings("input").val("")});'
			// packages on/off
			. '$(".rrm-pk-on").on("change",function(){var c=$(this).closest(".rrm-pkcol");c.toggleClass("off",!this.checked);c.find("input[name$=\'[on]\']").val(this.checked?"1":"")});'
			// counters & serp
			. 'function cnt(el){var m=+el.dataset.max,l=el.value.length,c=$(el).closest(".rrm-field").find(".rrm-count");c.text(l+" / "+m).toggleClass("over",l>m)}$("[data-max]").each(function(){cnt(this)}).on("input",function(){cnt(this)});'
			. '$("input[name=seo_title],input[name=title]").on("input",function(){var t=$("input[name=seo_title]").val()||$("input[name=title]").val();$("[data-serp=t]").text(t)});$("textarea[name=seo_desc]").on("input",function(){$("[data-serp=d]").text(this.value||"Your description shows here.")});'
			// filter & search
			. '$(".rrm-chips button").on("click",function(){$(".rrm-chips button").removeClass("on");$(this).addClass("on");flt()});$(".rrm-search").on("input",flt);'
			. 'function flt(){var f=$(".rrm-chips .on").data("f")||"",s=($(".rrm-search").val()||"").toLowerCase();$(".rrm-item").each(function(){var i=$(this),ok=(!f||(" "+i.data("f")+" ").indexOf(" "+f+" ")>-1)&&(!s||String(i.data("s")).indexOf(s)>-1);i.toggle(ok)})}'
			// drag order
			. 'var dragEl=null;$(".rrm-grid .rrm-item").attr("draggable",true).on("dragstart",function(e){dragEl=this;$(this).addClass("drag")}).on("dragend",function(){$(this).removeClass("drag");$(".rrm-item").removeClass("over");save()}).on("dragover",function(e){e.preventDefault();if(this!==dragEl){$(".rrm-item").removeClass("over");$(this).addClass("over")}}).on("drop",function(e){e.preventDefault();if(dragEl&&this!==dragEl){var a=$(dragEl),b=$(this);a.index()<b.index()?b.after(a):b.before(a)}});'
			. 'function save(){var g=$(".rrm-grid"),ids=g.find(".rrm-item").map(function(){return $(this).data("id")}).get().join(",");$.get(ajaxurl.replace("admin-ajax.php","admin-post.php"),{action:"rrm_action",do:"order",id:0,ids:ids,_wpnonce:"' . esc_js( $order ) . '"}).done(function(){$("body").append("<div class=\'rrm-toast\'>✓ Order saved</div>")})}'
			. '});';
	}
}
RR_Site_Manager::init();
