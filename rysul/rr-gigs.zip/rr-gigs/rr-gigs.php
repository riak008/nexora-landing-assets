<?php
/**
 * Plugin Name: RR Gigs
 * Description: Fiverr-style gigs for this site. Create, edit or remove gigs in Gigs: cover image, packages (Basic / Standard / Premium), Fiverr and Upwork links and reviews. Cards and gig pages update automatically. Works with any theme and needs no other plugin; if Nexora Pay is active, its button is used for direct orders.
 * Version: 1.0.0
 * Author: Rysul Islam Riak
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RR_Gigs {
	const PT  = 'rr_gig';
	const TAX = 'rr_gig_cat';
	const META = array( 'rr_label', 'rr_platform', 'rr_fiverr', 'rr_upwork', 'rr_rating', 'rr_reviews', 'rr_quote', 'rr_proof', 'rr_packages' );

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'boxes' ) );
		add_action( 'save_post_' . self::PT, array( __CLASS__, 'save' ) );
		add_shortcode( 'rr_gigs', array( __CLASS__, 'grid' ) );
		add_shortcode( 'rr_gig_market', array( __CLASS__, 'market' ) );
		add_shortcode( 'rr_gig', array( __CLASS__, 'single' ) );
		add_filter( 'template_include', array( __CLASS__, 'template' ), 99 );
		add_action( 'admin_menu', array( __CLASS__, 'settings_menu' ) );
		add_filter( 'manage_' . self::PT . '_posts_columns', array( __CLASS__, 'cols' ) );
		add_action( 'manage_' . self::PT . '_posts_custom_column', array( __CLASS__, 'col' ), 10, 2 );
	}

	public static function opt( $k, $d = '' ) {
		$o = get_option( 'rr_gigs_settings', array() );
		return isset( $o[ $k ] ) && '' !== $o[ $k ] ? $o[ $k ] : $d;
	}

	public static function register() {
		register_post_type( self::PT, array(
			'labels'        => array( 'name' => 'Gigs', 'singular_name' => 'Gig', 'add_new' => 'Add New Gig', 'add_new_item' => 'Add New Gig', 'edit_item' => 'Edit Gig', 'all_items' => 'All Gigs', 'featured_image' => 'Gig cover image', 'set_featured_image' => 'Set gig cover (1280×800)' ),
			'public'        => true,
			'show_in_rest'  => true,
			'menu_icon'     => 'dashicons-cart',
			'menu_position' => 20,
			'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes', 'custom-fields' ),
			'has_archive'   => false,
			'rewrite'       => array( 'slug' => 'hire-me', 'with_front' => false ),
		) );
		register_taxonomy( self::TAX, self::PT, array( 'label' => 'Gig categories', 'labels' => array( 'name' => 'Gig categories', 'singular_name' => 'Gig category' ), 'public' => false, 'show_ui' => true, 'hierarchical' => true, 'show_in_rest' => true, 'show_admin_column' => true ) );
		foreach ( self::META as $k ) {
			register_post_meta( self::PT, $k, array( 'type' => 'string', 'single' => true, 'show_in_rest' => true, 'auth_callback' => function () { return current_user_can( 'edit_posts' ); } ) );
		}
		if ( get_option( 'rr_gigs_flush' ) !== '1' ) {
			flush_rewrite_rules( false );
			update_option( 'rr_gigs_flush', '1' );
		}
	}

	/* ---------- admin ---------- */

	public static function boxes() {
		add_meta_box( 'rr_gig_pk', 'Packages (like Fiverr: leave Standard / Premium empty for a single package)', array( __CLASS__, 'box_pk' ), self::PT, 'normal', 'high' );
		add_meta_box( 'rr_gig_info', 'Gig details', array( __CLASS__, 'box_info' ), self::PT, 'normal', 'high' );
	}

	public static function packages( $id ) {
		$p = json_decode( (string) get_post_meta( $id, 'rr_packages', true ), true );
		$out = array();
		foreach ( is_array( $p ) ? $p : array() as $x ) {
			if ( ! empty( $x['name'] ) && isset( $x['price'] ) && '' !== $x['price'] ) {
				$x['features'] = isset( $x['features'] ) ? ( is_array( $x['features'] ) ? $x['features'] : array_filter( array_map( 'trim', preg_split( '/\r?\n/', $x['features'] ) ) ) ) : array();
				$out[] = $x;
			}
		}
		return $out;
	}

	public static function box_pk( $post ) {
		wp_nonce_field( 'rr_gig_save', 'rr_gig_nonce' );
		$p = self::packages( $post->ID );
		$names = array( 'Basic', 'Standard', 'Premium' );
		echo '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px">';
		for ( $i = 0; $i < 3; $i++ ) {
			$x = isset( $p[ $i ] ) ? $p[ $i ] : array();
			$v = function ( $k, $d = '' ) use ( $x ) { return isset( $x[ $k ] ) ? $x[ $k ] : $d; };
			echo '<div style="border:1px solid #dcdcde;border-radius:8px;padding:12px"><p><label>Package name<br><input class="widefat" name="rr_pk[' . $i . '][name]" value="' . esc_attr( $v( 'name', $i ? '' : $names[0] ) ) . '" placeholder="' . esc_attr( $names[ $i ] ) . '"></label></p>';
			echo '<p><label>Price (USD)<br><input class="widefat" type="number" step="1" min="0" name="rr_pk[' . $i . '][price]" value="' . esc_attr( $v( 'price' ) ) . '"></label></p>';
			echo '<p><label>Delivery (days)<br><input class="widefat" type="number" min="1" name="rr_pk[' . $i . '][days]" value="' . esc_attr( $v( 'days' ) ) . '"></label></p>';
			echo '<p><label>Revisions (number or Unlimited)<br><input class="widefat" name="rr_pk[' . $i . '][rev]" value="' . esc_attr( $v( 'rev' ) ) . '"></label></p>';
			echo '<p><label>Short description<br><input class="widefat" name="rr_pk[' . $i . '][desc]" value="' . esc_attr( $v( 'desc' ) ) . '"></label></p>';
			echo '<p><label>What\'s included (one per line)<br><textarea class="widefat" rows="6" name="rr_pk[' . $i . '][features]">' . esc_textarea( implode( "\n", (array) $v( 'features', array() ) ) ) . '</textarea></label></p></div>';
		}
		echo '</div><p class="description">Direct orders use Nexora Pay when it is active (price × BDT rate in Gigs › Settings). Otherwise the order button opens your contact page.</p>';
	}

	public static function box_info( $post ) {
		$f = array(
			'rr_label'    => array( 'Category label shown on the page', 'e.g. Local SEO' ),
			'rr_platform' => array( 'Badge (Fiverr or Upwork, empty for none)', 'Fiverr' ),
			'rr_fiverr'   => array( 'Fiverr gig URL', 'https://www.fiverr.com/...' ),
			'rr_upwork'   => array( 'Upwork project URL', 'https://www.upwork.com/services/product/...' ),
			'rr_rating'   => array( 'Rating', '5.0' ),
			'rr_reviews'  => array( 'Number of reviews', '9' ),
			'rr_quote'    => array( 'Client review (quote)', '' ),
			'rr_proof'    => array( 'Results image (media ID, optional)', '' ),
		);
		echo '<p style="color:#555">Title = "I will …" headline · Excerpt = short card text · Content = About this gig · Featured image = gig cover · Gig categories = filter chips on the Gigs page.</p><table class="form-table">';
		foreach ( $f as $k => $l ) {
			$val = get_post_meta( $post->ID, $k, true );
			echo '<tr><th><label for="' . esc_attr( $k ) . '">' . esc_html( $l[0] ) . '</label></th><td>';
			if ( 'rr_quote' === $k ) {
				echo '<textarea id="' . esc_attr( $k ) . '" name="' . esc_attr( $k ) . '" rows="3" class="large-text">' . esc_textarea( $val ) . '</textarea>';
			} else {
				echo '<input id="' . esc_attr( $k ) . '" name="' . esc_attr( $k ) . '" value="' . esc_attr( $val ) . '" placeholder="' . esc_attr( $l[1] ) . '" class="regular-text">';
			}
			echo '</td></tr>';
		}
		echo '</table>';
	}

	public static function save( $id ) {
		if ( ! isset( $_POST['rr_gig_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['rr_gig_nonce'] ) ), 'rr_gig_save' ) || ! current_user_can( 'edit_post', $id ) ) {
			return;
		}
		foreach ( array( 'rr_label', 'rr_platform', 'rr_rating', 'rr_reviews', 'rr_proof' ) as $k ) {
			if ( isset( $_POST[ $k ] ) ) {
				update_post_meta( $id, $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) );
			}
		}
		foreach ( array( 'rr_fiverr', 'rr_upwork' ) as $k ) {
			if ( isset( $_POST[ $k ] ) ) {
				update_post_meta( $id, $k, esc_url_raw( wp_unslash( $_POST[ $k ] ) ) );
			}
		}
		if ( isset( $_POST['rr_quote'] ) ) {
			update_post_meta( $id, 'rr_quote', sanitize_textarea_field( wp_unslash( $_POST['rr_quote'] ) ) );
		}
		$pk = array();
		foreach ( isset( $_POST['rr_pk'] ) ? (array) wp_unslash( $_POST['rr_pk'] ) : array() as $x ) {
			if ( empty( $x['name'] ) || '' === ( $x['price'] ?? '' ) ) {
				continue;
			}
			$rev  = trim( sanitize_text_field( $x['rev'] ?? '' ) );
			$pk[] = array(
				'name'     => sanitize_text_field( $x['name'] ),
				'price'    => (float) $x['price'],
				'days'     => max( 1, (int) ( $x['days'] ?? 1 ) ),
				'rev'      => is_numeric( $rev ) ? (int) $rev : ( $rev ?: '1' ),
				'desc'     => sanitize_text_field( $x['desc'] ?? '' ),
				'features' => array_values( array_filter( array_map( 'sanitize_text_field', preg_split( '/\r?\n/', (string) ( $x['features'] ?? '' ) ) ) ) ),
			);
		}
		update_post_meta( $id, 'rr_packages', wp_json_encode( $pk ) );
	}

	public static function cols( $c ) {
		return array_slice( $c, 0, 1, true ) + array( 'rr_img' => 'Cover', 'rr_from' => 'From' ) + array_slice( $c, 1, null, true );
	}

	public static function col( $c, $id ) {
		if ( 'rr_img' === $c ) {
			echo get_the_post_thumbnail( $id, array( 96, 60 ) );
		} elseif ( 'rr_from' === $c ) {
			$p = self::packages( $id );
			echo $p ? '$' . esc_html( $p[0]['price'] ) : '—';
		}
	}

	public static function settings_menu() {
		add_submenu_page( 'edit.php?post_type=' . self::PT, 'Gig settings', 'Settings', 'manage_options', 'rr-gig-settings', array( __CLASS__, 'settings_page' ) );
	}

	public static function settings_page() {
		if ( isset( $_POST['rr_gs'] ) && check_admin_referer( 'rr_gs' ) ) {
			update_option( 'rr_gigs_settings', array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['rr_gs'] ) ) );
			echo '<div class="updated"><p>Saved.</p></div>';
		}
		$f = array( 'name' => 'Seller name', 'photo' => 'Seller photo URL', 'rate' => 'BDT per USD for direct payments (Nexora Pay)', 'upwork' => 'Upwork profile URL', 'fiverr' => 'Fiverr profile URL', 'thanks' => 'Thank-you page URL after payment', 'seller' => 'Seller tagline', 'stats' => 'Seller stats line' );
		echo '<div class="wrap"><h1>Gig settings</h1><form method="post">';
		wp_nonce_field( 'rr_gs' );
		echo '<table class="form-table">';
		foreach ( $f as $k => $l ) {
			echo '<tr><th>' . esc_html( $l ) . '</th><td><input class="regular-text" name="rr_gs[' . esc_attr( $k ) . ']" value="' . esc_attr( self::opt( $k ) ) . '"></td></tr>';
		}
		echo '</table>';
		submit_button();
		echo '</form></div>';
	}

	/* ---------- front end ---------- */

	public static function card( $id ) {
		$p     = self::packages( $id );
		$terms = wp_get_post_terms( $id, self::TAX, array( 'fields' => 'slugs' ) );
		$plat  = get_post_meta( $id, 'rr_platform', true );
		$cls   = 'upwork' === strtolower( $plat ) ? 'up' : 'fv';
		$rv    = get_post_meta( $id, 'rr_reviews', true );
		$photo = self::opt( 'photo', '' );
		$img   = get_the_post_thumbnail( $id, 'large', array( 'loading' => 'lazy', 'alt' => esc_attr( get_the_title( $id ) ) ) );
		return '<a class="rr-gig" data-f="' . esc_attr( implode( ' ', is_array( $terms ) ? $terms : array() ) ) . '" href="' . esc_url( get_permalink( $id ) ) . '"><div class="rr-gig-img">' . $img . '</div><div class="rr-gig-body">'
			. '<div class="rr-gig-seller">' . ( $photo ? '<img src="' . esc_url( $photo ) . '" alt="">' : '' ) . esc_html( self::opt( 'name', get_bloginfo( 'name' ) ) ) . ( $plat ? '<span class="rr-badge ' . $cls . '">' . esc_html( $plat ) . '</span>' : '' ) . '</div>'
			. '<div class="rr-gig-title">' . esc_html( get_the_title( $id ) ) . '</div><div class="rr-gig-rate"><b>★</b> ' . esc_html( get_post_meta( $id, 'rr_rating', true ) ?: '5.0' ) . ( $rv ? ' <span>(' . esc_html( $rv ) . ')</span>' : '' ) . '</div>'
			. '<div class="rr-gig-foot">Starting at<strong>$' . esc_html( $p ? self::num( $p[0]['price'] ) : '—' ) . '</strong></div></div></a>';
	}

	private static function num( $n ) {
		return floor( $n ) == $n ? number_format( $n ) : number_format( $n, 2 );
	}

	private static function query( $a ) {
		$q = array( 'post_type' => self::PT, 'posts_per_page' => (int) $a['limit'], 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'DESC' ), 'no_found_rows' => true, 'fields' => 'ids' );
		if ( $a['cat'] ) {
			$q['tax_query'] = array( array( 'taxonomy' => self::TAX, 'field' => 'slug', 'terms' => array_map( 'trim', explode( ',', $a['cat'] ) ) ) );
		}
		if ( $a['platform'] ) {
			$q['meta_query'] = array( array( 'key' => 'rr_platform', 'value' => $a['platform'] ) );
		}
		if ( $a['exclude'] ) {
			$q['post__not_in'] = array_map( 'intval', explode( ',', $a['exclude'] ) );
		}
		if ( $a['ids'] ) {
			$q['post__in'] = array_map( 'intval', explode( ',', $a['ids'] ) );
			$q['orderby']  = 'post__in';
		}
		return get_posts( $q );
	}

	/** [rr_gigs limit="4" cat="local-seo" platform="Upwork" exclude="" ids=""] */
	public static function grid( $atts ) {
		$a   = shortcode_atts( array( 'limit' => -1, 'cat' => '', 'platform' => '', 'exclude' => '', 'ids' => '' ), $atts );
		$ids = self::query( $a );
		if ( count( $ids ) < (int) $a['limit'] && $a['cat'] ) {
			$more = self::query( array( 'limit' => (int) $a['limit'] - count( $ids ), 'cat' => '', 'platform' => '', 'ids' => '', 'exclude' => implode( ',', array_merge( $ids, $a['exclude'] ? explode( ',', $a['exclude'] ) : array() ) ) ) );
			$ids  = array_merge( $ids, $more );
		}
		return $ids ? '<div class="rr-gigs">' . implode( '', array_map( array( __CLASS__, 'card' ), $ids ) ) . '</div>' : '';
	}

	/** [rr_gig_market] – filter chips from Gig categories + all gigs. */
	public static function market() {
		$terms = get_terms( array( 'taxonomy' => self::TAX, 'hide_empty' => true ) );
		$h     = '<div class="rr-chipsf"><button data-f="all" class="on">All gigs</button>';
		foreach ( is_array( $terms ) ? $terms : array() as $t ) {
			$h .= '<button data-f="' . esc_attr( $t->slug ) . '">' . esc_html( $t->name ) . '</button>';
		}
		$h .= '</div><div class="rr-market">' . self::grid( array() ) . '</div>';
		$h .= '<script>document.addEventListener("click",function(e){var b=e.target.closest(".rr-chipsf button");if(!b)return;var f=b.dataset.f;b.parentNode.querySelectorAll("button").forEach(function(x){x.classList.toggle("on",x===b)});document.querySelectorAll(".rr-market .rr-gig").forEach(function(c){c.style.display=(f=="all"||(" "+c.dataset.f+" ").indexOf(" "+f+" ")>-1)?"":"none"})});</script>';
		return $h;
	}

	private static function revs( $r ) {
		return is_numeric( $r ) ? $r . ' revision' . ( 1 == $r ? '' : 's' ) : $r . ' revisions';
	}

	private static function pay_button( $usd, $label, $id ) {
		$rate = (float) self::opt( 'rate', 122 );
		$bdt  = (int) round( $usd * $rate );
		$txt  = 'Continue (৳' . number_format( $bdt ) . ' · $' . self::num( $usd ) . ')';
		if ( shortcode_exists( 'nexora_pay_button' ) ) {
			return do_shortcode( '[nexora_pay_button amount="' . $bdt . '" label="' . esc_attr( $txt ) . '" description="' . esc_attr( get_the_title( $id ) . ' – ' . $label . ' package' ) . '" success_url="' . esc_url( self::opt( 'thanks', home_url( '/thank-you/' ) ) ) . '"]' );
		}
		return '<a class="rr-paybtn" href="' . esc_url( home_url( '/contact/' ) ) . '">' . esc_html( 'Continue ($' . self::num( $usd ) . ')' ) . '</a>';
	}

	/** The gig page body, used inside the "gig-page-template" page so header, footer and styles come from the site design. */
	public static function single() {
		$post = get_queried_object();
		if ( ! $post instanceof WP_Post || self::PT !== $post->post_type ) {
			$p    = get_posts( array( 'post_type' => self::PT, 'numberposts' => 1 ) );
			$post = $p ? $p[0] : null;
		}
		if ( ! $post ) {
			return '';
		}
		$id    = $post->ID;
		$pk    = self::packages( $id );
		$rate  = (float) self::opt( 'rate', 122 );
		$label = get_post_meta( $id, 'rr_label', true );
		$fv    = get_post_meta( $id, 'rr_fiverr', true );
		$up    = get_post_meta( $id, 'rr_upwork', true );
		$rt    = get_post_meta( $id, 'rr_rating', true ) ?: '5.0';
		$rv    = get_post_meta( $id, 'rr_reviews', true );
		$photo = self::opt( 'photo', '' );
		$name  = self::opt( 'name', get_bloginfo( 'name' ) );

		$l  = '<nav class="rr-crumbs"><a href="' . esc_url( home_url( '/' ) ) . '">Home</a> › <a href="' . esc_url( home_url( '/hire-me/' ) ) . '">Gigs</a>' . ( $label ? ' › <span>' . esc_html( $label ) . '</span>' : '' ) . '</nav>';
		$l .= '<h1 class="rr-gt">' . esc_html( get_the_title( $id ) ) . '</h1>';
		$l .= '<div class="rr-seller">' . ( $photo ? '<img src="' . esc_url( $photo ) . '" alt="' . esc_attr( $name ) . '">' : '' ) . '<div><b>' . esc_html( $name ) . '</b><span>' . esc_html( self::opt( 'seller', '' ) ) . '</span><em><b class="st">★ ' . esc_html( $rt ) . '</b>' . ( $rv ? ' (' . esc_html( $rv ) . ' reviews)' : '' ) . ( self::opt( 'stats' ) ? ' · ' . esc_html( self::opt( 'stats' ) ) : '' ) . '</em></div></div>';
		$l .= '<div class="rr-gcover">' . get_the_post_thumbnail( $id, 'full', array( 'fetchpriority' => 'high' ) ) . '</div>';
		$l .= '<h2 class="rr-gh">About this gig</h2><div class="rr-gabout">' . apply_filters( 'the_content', $post->post_content ) . '</div>';
		$proof = (int) get_post_meta( $id, 'rr_proof', true );
		if ( $proof ) {
			$l .= '<h2 class="rr-gh">Real results from a similar project</h2><div class="rr-gproof">' . wp_get_attachment_image( $proof, 'large', false, array( 'loading' => 'lazy' ) ) . '</div>';
		}
		if ( $pk ) {
			$l .= '<h2 class="rr-gh">Compare packages</h2><div class="rr-cmp"><table><tr><th>Package</th>';
			foreach ( $pk as $x ) {
				$l .= '<td><b>' . esc_html( $x['name'] ) . '</b><small>' . esc_html( $x['desc'] ) . '</small></td>';
			}
			$l .= '</tr><tr><th>Price</th>';
			foreach ( $pk as $x ) {
				$l .= '<td><b>$' . esc_html( self::num( $x['price'] ) ) . '</b><small>≈ ৳' . esc_html( number_format( round( $x['price'] * $rate ) ) ) . '</small></td>';
			}
			$l .= '</tr><tr><th>Delivery</th>';
			foreach ( $pk as $x ) {
				$l .= '<td>' . (int) $x['days'] . ' days</td>';
			}
			$l .= '</tr><tr><th>Revisions</th>';
			foreach ( $pk as $x ) {
				$l .= '<td>' . esc_html( $x['rev'] ) . '</td>';
			}
			$l   .= '</tr>';
			$all  = array();
			foreach ( $pk as $x ) {
				foreach ( $x['features'] as $f ) {
					if ( 0 !== strpos( $f, 'Everything in' ) && ! in_array( $f, $all, true ) ) {
						$all[] = $f;
					}
				}
			}
			foreach ( $all as $f ) {
				$l .= '<tr><th>' . esc_html( $f ) . '</th>';
				$inherit = false;
				foreach ( $pk as $j => $x ) {
					$has = in_array( $f, $x['features'], true );
					if ( ! $has && $j > 0 ) {
						foreach ( $x['features'] as $g ) {
							if ( 0 === strpos( $g, 'Everything in' ) ) {
								for ( $k = 0; $k < $j; $k++ ) {
									$has = $has || in_array( $f, $pk[ $k ]['features'], true );
								}
							}
						}
					}
					$l .= '<td>' . ( $has ? '<i class="y">✓</i>' : '<i class="n">–</i>' ) . '</td>';
				}
				$l .= '</tr>';
			}
			$l .= '<tr><th></th>';
			foreach ( $pk as $j => $x ) {
				$l .= '<td><a href="#" data-pick="' . $j . '" class="rr-pick">Select</a></td>';
			}
			$l .= '</tr></table></div>';
		}
		$l .= '<h2 class="rr-gh">How it works</h2><div class="rr-mini-steps"><div><b>1</b>Choose a package and pay</div><div><b>2</b>Send access and details</div><div><b>3</b>I deliver with a report</div><div><b>4</b>Revisions until it is right</div></div>';
		$q = get_post_meta( $id, 'rr_quote', true );
		if ( $q ) {
			$l .= '<h2 class="rr-gh">Reviews</h2><div class="rr-quote"><div class="s">★★★★★</div><blockquote>“' . esc_html( $q ) . '”</blockquote><cite><b>Verified client</b>' . esc_html( $up ? 'Upwork' : 'Fiverr' ) . ' · ' . esc_html( $rt ) . '</cite></div>';
		}
		$l .= '<h2 class="rr-gh">FAQ</h2><div class="rr-faq">';
		foreach ( array(
			array( 'What do you need from me to start?', 'Your website URL, a WordPress login (or staff access), Google Search Console and, for local SEO, your Google Business Profile. I send a short checklist after the order.' ),
			array( 'Can I order this on Fiverr or Upwork instead?', 'Yes. Use the Fiverr or Upwork button next to the package to order with their payment protection.' ),
			array( 'What if I am not happy with the work?', 'Every package includes revisions. I keep working until the agreed scope is delivered and explained.' ),
			array( 'How do I pay from outside Bangladesh?', 'Order on Fiverr or Upwork, or contact me for a direct international invoice.' ),
		) as $f ) {
			$l .= '<details><summary>' . esc_html( $f[0] ) . '</summary><p>' . esc_html( $f[1] ) . '</p></details>';
		}
		$l .= '</div>';

		// buy box
		$b = '<aside class="rr-buybox"><div class="rr-ptabs" style="grid-template-columns:repeat(' . max( 1, count( $pk ) ) . ',1fr)">';
		foreach ( $pk as $j => $x ) {
			$b .= '<button type="button" data-i="' . $j . '"' . ( 0 === $j ? ' class="on"' : '' ) . '>' . esc_html( 1 === count( $pk ) ? 'Package' : $x['name'] ) . '</button>';
		}
		$b .= '</div>';
		foreach ( $pk as $j => $x ) {
			$b .= '<div class="rr-pane' . ( 0 === $j ? ' on' : '' ) . '"><div class="rr-pane-h"><b>' . esc_html( $x['desc'] ?: $x['name'] ) . '</b><span>$' . esc_html( self::num( $x['price'] ) ) . '</span></div>';
			$b .= '<div class="rr-pane-bdt">≈ ৳' . esc_html( number_format( round( $x['price'] * $rate ) ) ) . ' for bKash / Nagad</div><div class="rr-pane-m"><span>⏱ ' . (int) $x['days'] . '-day delivery</span><span>↻ ' . esc_html( self::revs( $x['rev'] ) ) . '</span></div><ul>';
			foreach ( $x['features'] as $f ) {
				$b .= '<li>' . esc_html( $f ) . '</li>';
			}
			$b .= '</ul>' . self::pay_button( (float) $x['price'], $x['name'], $id ) . '<div class="rr-alt">';
			if ( $fv ) {
				$b .= '<a href="' . esc_url( $fv ) . '" target="_blank" rel="noopener">Order on Fiverr</a>';
			}
			$b .= '<a href="' . esc_url( $up ?: self::opt( 'upwork', '#' ) ) . '" target="_blank" rel="noopener">' . ( $up ? 'Order this project on Upwork' : 'Hire me on Upwork' ) . '</a><a href="' . esc_url( home_url( '/seo-consultation/' ) ) . '">Contact me first</a></div></div>';
		}
		$b .= '<p class="rr-secure">🔒 Secure payment · reply within 12 hours</p></aside>';
		$js = '<script>if(!window.rrTabs){window.rrTabs=1;document.addEventListener("click",function(e){var b=e.target.closest(".rr-ptabs button,[data-pick]");if(!b)return;var i=b.dataset.i!==undefined?b.dataset.i:b.dataset.pick;var box=document.querySelector(".rr-buybox");if(!box)return;box.querySelectorAll(".rr-ptabs button").forEach(function(x){x.classList.toggle("on",x.dataset.i==i)});box.querySelectorAll(".rr-pane").forEach(function(p,j){p.classList.toggle("on",j==i)});if(b.dataset.pick!==undefined){e.preventDefault();box.scrollIntoView({behavior:"smooth",block:"center"})}})}</script>';

		$terms = wp_get_post_terms( $id, self::TAX, array( 'fields' => 'slugs' ) );
		$more  = self::grid( array( 'limit' => 4, 'cat' => is_array( $terms ) && $terms ? $terms[0] : '', 'exclude' => (string) $id ) );
		$h  = '<section class="rr-sec rr-gigpage"><div class="rr-wrap rr-ggrid"><article class="rr-gl">' . $l . '</article>' . $b . '</div></section>' . $js;
		$h .= $more ? '<section class="rr-sec rr-soft"><div class="rr-wrap"><p class="rr-pill-l">More gigs</p><h2 class="rr-ph2">Other gigs you may need</h2>' . $more . '</div></section>' : '';
		return $h;
	}

	public static function template( $t ) {
		if ( is_singular( self::PT ) ) {
			return __DIR__ . '/single.php';
		}
		return $t;
	}

	public static function template_id() {
		$p = get_page_by_path( 'gig-page-template' );
		return $p ? (int) $p->ID : 0;
	}
}
RR_Gigs::init();
register_activation_hook( __FILE__, function () {
	delete_option( 'rr_gigs_flush' );
} );
