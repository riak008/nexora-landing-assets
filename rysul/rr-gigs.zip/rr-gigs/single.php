<?php
/** Gig page: renders the "gig-page-template" page (Elementor) whose [rr_gig] shortcode shows this gig. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$rr_tpl = RR_Gigs::template_id();
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'rr-gig-page' ); ?>>
<?php
wp_body_open();
if ( $rr_tpl && class_exists( '\Elementor\Plugin' ) ) {
	echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $rr_tpl, true ); // phpcs:ignore WordPress.Security.EscapeOutput
} else {
	echo '<main>' . do_shortcode( '[rr_gig]' ) . '</main>'; // phpcs:ignore WordPress.Security.EscapeOutput
}
wp_footer();
?>
</body>
</html>
