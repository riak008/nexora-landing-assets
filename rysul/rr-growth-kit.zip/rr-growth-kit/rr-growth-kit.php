<?php
/**
 * Plugin Name: RR Growth Kit
 * Description: Lead capture and tracking for this site: WhatsApp and call buttons, mobile action bar, free-audit popup, cookie consent, GA4 / Tag Manager / Clarity / Meta Pixel / LinkedIn Insight with conversion events, first-touch attribution and Service schema for gigs. Settings → Growth Kit. Needs no other plugin.
 * Version: 1.0.0
 * Author: Rysul Islam Riak
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RR_Growth_Kit {
	const OPT = 'rr_growth_kit';

	public static function defaults() {
		return array(
			'whatsapp'   => '8801625830004',
			'phone'      => '+8801625830004',
			'wa_text'    => 'Hi Rysul, I found your website and want to talk about SEO for my business.',
			'popup'      => '1',
			'popup_url'  => '/seo-audit/',
			'popup_skip' => '/seo-audit/,/thank-you/,/book/,/start-project/,/free-seo-audit/',
			'bar'        => '1',
			'consent'    => '1',
			'ga4'        => '',
			'gtm'        => '',
			'clarity'    => '',
			'meta_pixel' => '',
			'linkedin'   => '',
			'gsc'        => '',
		);
	}

	public static function o( $k ) {
		$o = wp_parse_args( get_option( self::OPT, array() ), self::defaults() );
		return isset( $o[ $k ] ) ? $o[ $k ] : '';
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'wp_head', array( __CLASS__, 'head' ), 1 );
		add_action( 'wp_body_open', array( __CLASS__, 'body_open' ), 1 );
		add_action( 'wp_footer', array( __CLASS__, 'footer' ), 50 );
	}

	/* ---------- settings ---------- */

	public static function menu() {
		add_options_page( 'Growth Kit', 'Growth Kit', 'manage_options', 'rr-growth-kit', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		if ( isset( $_POST['rrg'] ) && check_admin_referer( 'rrg_save' ) ) {
			$in  = wp_unslash( (array) $_POST['rrg'] );
			$out = array();
			foreach ( self::defaults() as $k => $d ) {
				$v = isset( $in[ $k ] ) ? $in[ $k ] : '';
				if ( in_array( $k, array( 'popup', 'bar', 'consent' ), true ) ) {
					$v = $v ? '1' : '0';
				}
				$out[ $k ] = sanitize_text_field( $v );
			}
			update_option( self::OPT, $out );
			echo '<div class="updated"><p>Saved.</p></div>';
		}
		$f = array(
			'Lead capture'           => array(
				'whatsapp'   => array( 'WhatsApp number (country code, digits only)', 'text' ),
				'phone'      => array( 'Phone for the call button', 'text' ),
				'wa_text'    => array( 'WhatsApp first message', 'text' ),
				'bar'        => array( 'Show WhatsApp / call buttons and the mobile action bar', 'check' ),
				'popup'      => array( 'Show the free SEO audit popup (exit intent or after 35 s, once a week)', 'check' ),
				'popup_url'  => array( 'Popup button link', 'text' ),
				'popup_skip' => array( 'Pages without the popup (comma separated paths)', 'text' ),
			),
			'Tracking (IDs only)'    => array(
				'ga4'        => array( 'Google Analytics 4 measurement ID (G-XXXXXXX)', 'text' ),
				'gtm'        => array( 'Google Tag Manager container ID (GTM-XXXXXX)', 'text' ),
				'clarity'    => array( 'Microsoft Clarity project ID', 'text' ),
				'meta_pixel' => array( 'Meta (Facebook) Pixel ID', 'text' ),
				'linkedin'   => array( 'LinkedIn Insight Tag partner ID', 'text' ),
				'gsc'        => array( 'Google Search Console HTML tag content (optional)', 'text' ),
				'consent'    => array( 'Ask for cookie consent before analytics and ads tracking (recommended for EU / UK visitors)', 'check' ),
			),
		);
		echo '<div class="wrap"><h1>Growth Kit</h1><p>Every click on WhatsApp, call, gigs, payment, booking, Fiverr, Upwork and forms is sent as an event to Google Analytics, Tag Manager, Meta and LinkedIn when their IDs are set.</p><form method="post">';
		wp_nonce_field( 'rrg_save' );
		foreach ( $f as $title => $rows ) {
			echo '<h2>' . esc_html( $title ) . '</h2><table class="form-table">';
			foreach ( $rows as $k => $r ) {
				$v = self::o( $k );
				echo '<tr><th>' . esc_html( $r[0] ) . '</th><td>';
				if ( 'check' === $r[1] ) {
					echo '<input type="checkbox" name="rrg[' . esc_attr( $k ) . ']" value="1"' . checked( '1', $v, false ) . '>';
				} else {
					echo '<input class="regular-text" name="rrg[' . esc_attr( $k ) . ']" value="' . esc_attr( $v ) . '">';
				}
				echo '</td></tr>';
			}
			echo '</table>';
		}
		submit_button();
		echo '</form></div>';
	}

	/* ---------- front end ---------- */

	private static function skip_path() {
		$path = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/', PHP_URL_PATH );
		foreach ( array_filter( array_map( 'trim', explode( ',', self::o( 'popup_skip' ) ) ) ) as $p ) {
			if ( $p && 0 === strpos( (string) $path, $p ) ) {
				return true;
			}
		}
		return false;
	}

	public static function head() {
		if ( is_admin() ) {
			return;
		}
		$consent = '1' === self::o( 'consent' );
		$ga4     = preg_replace( '/[^A-Z0-9-]/i', '', self::o( 'ga4' ) );
		$gtm     = preg_replace( '/[^A-Z0-9-]/i', '', self::o( 'gtm' ) );
		$clarity = preg_replace( '/[^a-z0-9]/i', '', self::o( 'clarity' ) );
		$pixel   = preg_replace( '/[^0-9]/', '', self::o( 'meta_pixel' ) );
		$li      = preg_replace( '/[^0-9]/', '', self::o( 'linkedin' ) );
		if ( self::o( 'gsc' ) ) {
			echo '<meta name="google-site-verification" content="' . esc_attr( self::o( 'gsc' ) ) . '">' . "\n";
		}
		// Consent mode first, so every tag starts in the right state.
		echo "<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}\n";
		echo 'window.rrConsent=(function(){try{return localStorage.getItem("rr_consent")}catch(e){return null}})();';
		if ( $consent ) {
			echo 'var g=window.rrConsent==="all"?"granted":"denied";gtag("consent","default",{ad_storage:g,ad_user_data:g,ad_personalization:g,analytics_storage:g,wait_for_update:500});';
		} else {
			echo 'window.rrConsent="all";';
		}
		echo "</script>\n";
		if ( $gtm ) {
			echo "<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','" . esc_js( $gtm ) . "');</script>\n";
		}
		if ( $ga4 ) {
			echo '<script async src="https://www.googletagmanager.com/gtag/js?id=' . esc_attr( $ga4 ) . '"></script><script>gtag("js",new Date());gtag("config","' . esc_js( $ga4 ) . '");</script>' . "\n";
		}
		// Marketing tags load only after consent (or right away when consent is off).
		$loaders = '';
		if ( $clarity ) {
			$loaders .= '(function(c,l,a,r,i,t,y){c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);})(window,document,"clarity","script","' . esc_js( $clarity ) . '");';
		}
		if ( $pixel ) {
			$loaders .= '!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version="2.0";n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","' . esc_js( $pixel ) . '");fbq("track","PageView");';
		}
		if ( $li ) {
			$loaders .= 'window._linkedin_partner_id="' . esc_js( $li ) . '";window._linkedin_data_partner_ids=window._linkedin_data_partner_ids||[];window._linkedin_data_partner_ids.push(window._linkedin_partner_id);(function(l){if(!l){window.lintrk=function(a,b){window.lintrk.q.push([a,b])};window.lintrk.q=[]}var s=document.getElementsByTagName("script")[0];var b=document.createElement("script");b.type="text/javascript";b.async=true;b.src="https://snap.licdn.com/li.lms-analytics/insight.min.js";s.parentNode.insertBefore(b,s);})(window.lintrk);';
		}
		echo '<script>window.rrLoadMarketing=function(){if(window.rrMkt)return;window.rrMkt=1;' . $loaders . '};if(window.rrConsent==="all")window.rrLoadMarketing();</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
		self::schema();
	}

	public static function body_open() {
		$gtm = preg_replace( '/[^A-Z0-9-]/i', '', self::o( 'gtm' ) );
		if ( $gtm ) {
			echo '<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=' . esc_attr( $gtm ) . '" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>';
		}
	}

	/** Service + offers for gig pages (RR Gigs), from the gig's packages. */
	private static function schema() {
		if ( ! is_singular( 'rr_gig' ) || ! class_exists( 'RR_Gigs' ) ) {
			return;
		}
		$id = get_queried_object_id();
		$pk = RR_Gigs::packages( $id );
		if ( ! $pk ) {
			return;
		}
		$offers = array();
		foreach ( $pk as $p ) {
			$offers[] = array( '@type' => 'Offer', 'name' => $p['name'] . ' – ' . $p['desc'], 'price' => (string) $p['price'], 'priceCurrency' => 'USD', 'availability' => 'https://schema.org/InStock', 'url' => get_permalink( $id ) );
		}
		$prices = wp_list_pluck( $pk, 'price' );
		$data   = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'Service',
			'name'            => get_the_title( $id ),
			'description'     => wp_strip_all_tags( get_the_excerpt( $id ) ),
			'serviceType'     => get_post_meta( $id, 'rr_label', true ),
			'url'             => get_permalink( $id ),
			'image'           => get_the_post_thumbnail_url( $id, 'full' ),
			'provider'        => array( '@type' => 'Person', 'name' => 'Rysul Islam Riak', 'url' => home_url( '/' ) ),
			'areaServed'      => 'Worldwide',
			'offers'          => array( '@type' => 'AggregateOffer', 'priceCurrency' => 'USD', 'lowPrice' => (string) min( $prices ), 'highPrice' => (string) max( $prices ), 'offerCount' => count( $pk ), 'offers' => $offers ),
		);
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
		$crumbs = array( '@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => array(
			array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => home_url( '/' ) ),
			array( '@type' => 'ListItem', 'position' => 2, 'name' => 'Gigs', 'item' => home_url( '/hire-me/' ) ),
			array( '@type' => 'ListItem', 'position' => 3, 'name' => get_the_title( $id ), 'item' => get_permalink( $id ) ),
		) );
		echo '<script type="application/ld+json">' . wp_json_encode( $crumbs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public static function footer() {
		if ( is_admin() ) {
			return;
		}
		$wa    = preg_replace( '/[^0-9]/', '', self::o( 'whatsapp' ) );
		$tel   = preg_replace( '/[^0-9+]/', '', self::o( 'phone' ) );
		$wa_u  = $wa ? 'https://wa.me/' . $wa . '?text=' . rawurlencode( self::o( 'wa_text' ) ) : '';
		$popup = '1' === self::o( 'popup' ) && ! self::skip_path();
		?>
<style id="rrg-css">
.rrg-fab{position:fixed;right:18px;bottom:18px;z-index:9990;display:flex;flex-direction:column;gap:10px}
.rrg-fab a{width:54px;height:54px;border-radius:50%;display:grid;place-items:center;box-shadow:0 14px 30px -10px rgba(2,6,23,.45);transition:transform .2s}
.rrg-fab a:hover{transform:translateY(-3px) scale(1.04)}
.rrg-wa{background:#25D366}.rrg-call{background:#0B1530}
.rrg-fab svg{width:28px;height:28px;fill:#fff}
.rrg-fab .rrg-wa:after{content:"";position:absolute;inset:0;border-radius:50%;box-shadow:0 0 0 0 rgba(37,211,102,.6);animation:rrgp 2.4s infinite}
.rrg-fab a{position:relative}
@keyframes rrgp{0%{box-shadow:0 0 0 0 rgba(37,211,102,.55)}70%{box-shadow:0 0 0 16px rgba(37,211,102,0)}100%{box-shadow:0 0 0 0 rgba(37,211,102,0)}}
.rrg-bar{display:none}
@media(max-width:767px){
 .rrg-fab{bottom:78px;right:12px}.rrg-fab .rrg-call{display:none}
 .rrg-bar{display:grid;grid-template-columns:1fr 1fr 1.3fr;position:fixed;left:0;right:0;bottom:0;z-index:9989;background:#fff;border-top:1px solid #E3E8F2;box-shadow:0 -10px 30px -16px rgba(15,23,42,.35);padding:8px 10px calc(8px + env(safe-area-inset-bottom));gap:8px}
 .rrg-bar a{display:flex;align-items:center;justify-content:center;gap:6px;height:46px;border-radius:12px;font:700 14px/1 Inter,system-ui,sans-serif;text-decoration:none;color:#0F172A;background:#F1F5FB}
 .rrg-bar a.p{background:linear-gradient(135deg,#F7C66A,#F2A93B);color:#1b1407}
 body{padding-bottom:64px}
}
.rrg-pop{position:fixed;inset:0;z-index:9999;background:rgba(11,21,48,.6);backdrop-filter:blur(4px);display:none;align-items:center;justify-content:center;padding:18px}
.rrg-pop.on{display:flex}
.rrg-box{position:relative;max-width:470px;width:100%;background:linear-gradient(160deg,#0B1530,#16295E);color:#fff;border-radius:24px;padding:34px 30px 28px;box-shadow:0 40px 80px -30px rgba(0,0,0,.6);font-family:Inter,system-ui,sans-serif;animation:rrgin .35s ease}
@keyframes rrgin{from{opacity:0;transform:translateY(14px) scale(.98)}to{opacity:1;transform:none}}
.rrg-box .t{display:inline-block;font:700 11.5px/1 Inter,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:#F2B544;background:rgba(242,181,68,.14);padding:7px 11px;border-radius:999px}
.rrg-box h3{font:800 28px/1.15 Poppins,Inter,sans-serif;margin:14px 0 10px;color:#fff}
.rrg-box h3 span{background:linear-gradient(90deg,#5B8CFF,#38BDF8);-webkit-background-clip:text;background-clip:text;color:transparent}
.rrg-box p{color:#C7D2EA;line-height:1.6;margin:0 0 16px;font-size:15.5px}
.rrg-box ul{list-style:none;padding:0;margin:0 0 20px;display:grid;gap:8px;font-size:14.5px}.rrg-box li:before{content:"✓";color:#38BDF8;font-weight:800;margin-right:8px}
.rrg-box .go{display:block;text-align:center;padding:16px;border-radius:12px;background:linear-gradient(135deg,#F7C66A,#F2A93B);color:#1b1407;font:700 16px/1 Inter,sans-serif;text-decoration:none}
.rrg-box .no{display:block;margin:12px auto 0;background:none;border:0;color:#94A3B8;font-size:13px;cursor:pointer}
.rrg-x{position:absolute;top:12px;right:14px;background:rgba(255,255,255,.08);border:0;color:#fff;width:34px;height:34px;border-radius:50%;font-size:18px;cursor:pointer}
.rrg-cc{position:fixed;left:16px;bottom:16px;z-index:9995;max-width:380px;background:#fff;border:1px solid #E3E8F2;border-radius:16px;padding:16px 18px;box-shadow:0 24px 50px -20px rgba(15,23,42,.35);font:14px/1.5 Inter,system-ui,sans-serif;color:#0F172A;display:none}
.rrg-cc.on{display:block}.rrg-cc p{margin:0 0 12px;color:#475569}.rrg-cc div{display:flex;gap:8px}
.rrg-cc button{flex:1;padding:11px;border-radius:10px;font-weight:700;cursor:pointer;border:1.5px solid #E3E8F2;background:#fff;color:#0F172A}
.rrg-cc button.a{background:#0B1530;border-color:#0B1530;color:#fff}
@media(max-width:767px){.rrg-cc{left:10px;right:10px;bottom:72px;max-width:none}}
</style>
		<?php if ( '1' === self::o( 'bar' ) && ( $wa_u || $tel ) ) : ?>
<div class="rrg-fab" aria-label="Contact">
			<?php if ( $wa_u ) : ?><a class="rrg-wa" href="<?php echo esc_url( $wa_u ); ?>" target="_blank" rel="noopener" aria-label="Chat on WhatsApp" data-rrg="whatsapp_click"><svg viewBox="0 0 32 32"><path d="M16 3C9 3 3.4 8.6 3.4 15.6c0 2.3.6 4.5 1.8 6.4L3 29l7.2-2.1c1.8 1 3.8 1.5 5.8 1.5 7 0 12.6-5.6 12.6-12.6S23 3 16 3zm0 23.1c-1.9 0-3.7-.5-5.3-1.5l-.4-.2-4.3 1.3 1.3-4.2-.3-.4c-1.1-1.7-1.6-3.6-1.6-5.5C5.4 9.8 10.2 5 16 5s10.6 4.8 10.6 10.6S21.8 26.1 16 26.1zm5.8-7.9c-.3-.2-1.9-.9-2.2-1s-.5-.2-.7.2-.8 1-1 1.2-.4.2-.7.1c-.3-.2-1.3-.5-2.5-1.6-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.5-.6c.2-.2.2-.3.3-.5s0-.4 0-.6c-.1-.2-.7-1.7-1-2.3-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4s-1.2 1.1-1.2 2.7 1.2 3.1 1.4 3.4c.2.2 2.3 3.6 5.6 5 .8.3 1.4.5 1.9.7.8.3 1.5.2 2.1.1.6-.1 1.9-.8 2.2-1.5.3-.8.3-1.4.2-1.5-.1-.2-.3-.3-.6-.4z"/></svg></a><?php endif; ?>
			<?php if ( $tel ) : ?><a class="rrg-call" href="tel:<?php echo esc_attr( $tel ); ?>" aria-label="Call" data-rrg="call_click"><svg viewBox="0 0 24 24"><path d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.2.2 2.4.6 3.6.1.3 0 .7-.2 1z"/></svg></a><?php endif; ?>
</div>
<nav class="rrg-bar" aria-label="Quick actions">
			<?php if ( $tel ) : ?><a href="tel:<?php echo esc_attr( $tel ); ?>" data-rrg="call_click">📞 Call</a><?php endif; ?>
			<?php if ( $wa_u ) : ?><a href="<?php echo esc_url( $wa_u ); ?>" target="_blank" rel="noopener" data-rrg="whatsapp_click">💬 WhatsApp</a><?php endif; ?>
<a class="p" href="<?php echo esc_url( home_url( self::o( 'popup_url' ) ?: '/seo-audit/' ) ); ?>" data-rrg="audit_cta_click">Free SEO audit</a>
</nav>
		<?php endif; ?>
		<?php if ( $popup ) : ?>
<div class="rrg-pop" id="rrg-pop" role="dialog" aria-modal="true" aria-labelledby="rrg-pop-t"><div class="rrg-box">
<button class="rrg-x" type="button" aria-label="Close" data-rrg-close>×</button>
<span class="t">Free · 60 seconds</span>
<h3 id="rrg-pop-t">Why isn't your site <span>getting more leads?</span></h3>
<p>Get a free SEO audit of your website: a live crawl of up to 15 pages with your score and the exact problems costing you rankings on Google and AI search.</p>
<ul><li>Technical &amp; on-page issues</li><li>Google Maps &amp; AI search readiness</li><li>A clear fix list, no obligation</li></ul>
<a class="go" href="<?php echo esc_url( home_url( self::o( 'popup_url' ) ?: '/seo-audit/' ) ); ?>" data-rrg="popup_audit_click">Run my free SEO audit →</a>
<button class="no" type="button" data-rrg-close>No thanks</button>
</div></div>
		<?php endif; ?>
		<?php if ( '1' === self::o( 'consent' ) ) : ?>
<div class="rrg-cc" id="rrg-cc" role="region" aria-label="Cookies"><p>We use cookies to understand traffic and improve the site. Analytics and ads cookies are only set if you accept.</p><div><button type="button" data-rrg-consent="necessary">Only necessary</button><button type="button" class="a" data-rrg-consent="all">Accept all</button></div></div>
		<?php endif; ?>
<script>
(function(){
 var ls={get:function(k){try{return localStorage.getItem(k)}catch(e){return null}},set:function(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
 /* first-touch attribution */
 var q=new URLSearchParams(location.search),attr=null;try{attr=JSON.parse(ls.get('rr_attr')||'null')}catch(e){}
 if(!attr){attr={source:q.get('utm_source')||(document.referrer?new URL(document.referrer).hostname:'direct'),medium:q.get('utm_medium')||(q.get('gclid')?'cpc':(document.referrer?'referral':'none')),campaign:q.get('utm_campaign')||'',landing:location.pathname,ts:Date.now()};ls.set('rr_attr',JSON.stringify(attr))}
 window.rrAttr=attr;
 document.querySelectorAll('form').forEach(function(f){if(f.querySelector('[name=rr_source]'))return;[['rr_source',attr.source],['rr_medium',attr.medium],['rr_campaign',attr.campaign],['rr_landing',attr.landing]].forEach(function(p){var i=document.createElement('input');i.type='hidden';i.name=p[0];i.value=p[1]||'';f.appendChild(i)})});
 /* events */
 function track(name,params){params=params||{};params.rr_source=attr.source;params.page=location.pathname;
  window.dataLayer=window.dataLayer||[];dataLayer.push(Object.assign({event:name},params));
  if(window.gtag)gtag('event',name,params);
  if(window.fbq){var map={whatsapp_click:'Contact',call_click:'Contact',begin_checkout:'InitiateCheckout',book_click:'Schedule',form_submit:'Lead',purchase:'Purchase',popup_audit_click:'Lead',audit_cta_click:'Lead'};if(map[name])fbq('track',map[name],params.value?{value:params.value,currency:params.currency||'USD'}:{})}
  if(window.lintrk&&/checkout|purchase|form_submit|book_click|whatsapp|call/.test(name))lintrk('track',{conversion_id:name});
 }
 window.rrTrack=track;
 document.addEventListener('click',function(e){var a=e.target.closest('a,button');if(!a)return;var h=a.getAttribute('href')||'',n=a.getAttribute('data-rrg');
  if(n)return track(n,{label:(a.textContent||'').trim().slice(0,60)});
  if(/wa\.me|whatsapp/.test(h))return track('whatsapp_click');
  if(/^tel:/.test(h))return track('call_click');
  if(/^mailto:/.test(h))return track('email_click');
  if(/fiverr\.com/.test(h))return track('fiverr_click',{label:h});
  if(/upwork\.com/.test(h))return track('upwork_click',{label:h});
  if(a.classList.contains('rr-payoneer'))return track('payoneer_click');
  if(a.classList.contains('nfp-pay-button')||a.closest('.nfp-pay-button-form')){var m=(a.textContent||'').match(/৳([\d,]+)/);return track('begin_checkout',{value:m?Number(m[1].replace(/,/g,'')):0,currency:'BDT',label:document.title})}
  if(/\/book\/|seo-consultation|start-project/.test(h))return track('book_click');
  if(/\/hire-me\/[^\/]+\/$/.test(h))return track('select_gig',{label:h});
  if(/\/portfolio\/[^\/]+\/$/.test(h))return track('view_case_study',{label:h});
 },true);
 document.addEventListener('submit',function(e){var f=e.target;track('form_submit',{label:f.id||f.className||f.action||'form'})},true);
 if(/\/thank-you\//.test(location.pathname))track('purchase',{currency:'BDT'});
 /* consent */
 var cc=document.getElementById('rrg-cc');if(cc&&!ls.get('rr_consent'))cc.classList.add('on');
 document.addEventListener('click',function(e){var b=e.target.closest('[data-rrg-consent]');if(!b)return;var v=b.getAttribute('data-rrg-consent');ls.set('rr_consent',v);cc&&cc.classList.remove('on');
  if(v==='all'){if(window.gtag)gtag('consent','update',{ad_storage:'granted',ad_user_data:'granted',ad_personalization:'granted',analytics_storage:'granted'});window.rrLoadMarketing&&window.rrLoadMarketing()}});
 /* popup */
 var pop=document.getElementById('rrg-pop');
 if(pop){var last=Number(ls.get('rr_pop')||0);if(Date.now()-last>7*864e5){var shown=false,show=function(){if(shown)return;shown=true;pop.classList.add('on');ls.set('rr_pop',String(Date.now()));track('popup_view')};
  setTimeout(show,35000);document.addEventListener('mouseout',function(e){if(!e.relatedTarget&&e.clientY<8)show()});
  var sc=function(){if(window.scrollY>document.body.scrollHeight*0.6&&window.innerWidth<768){show();window.removeEventListener('scroll',sc)}};window.addEventListener('scroll',sc,{passive:true});}
  pop.addEventListener('click',function(e){if(e.target===pop||e.target.hasAttribute('data-rrg-close')){pop.classList.remove('on')}});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')pop.classList.remove('on')});}
})();
</script>
		<?php
	}
}
RR_Growth_Kit::init();
